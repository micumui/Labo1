package entidades;

public class Espectaculo {
    
    int id;
    int precio;
    String titulo;
    int fechaHora;
    int idEstadio;

    //Constructores
    public Espectaculo() {
    }

    public Espectaculo(int id, int precio, String titulo, int fechaHora,int idEstadio) {
        this.id = id;
        this.precio = precio;
        this.titulo = titulo;
        this.fechaHora = fechaHora;
        this.idEstadio = idEstadio;
    }


    //Getters
    public int getId() 
    {
        return id;
    }
    public int getPrecio() 
    {
        return precio;
    }
    public String getTitulo() 
    {
        return titulo;
    }
    public int getFechaHora() 
    {
        return fechaHora;
    }
    public int getIdEstadio() 
    {
        return idEstadio;
    }
    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setPrecio(int precio) 
    {
        this.precio = precio;
    }
    public void setTitulo(String titulo) 
    {
        this.titulo = titulo;
    }
    public void setFechaHora(int fechaHora) 
    {
        this.fechaHora = fechaHora;
    }
    public void setIdEstadio(int idEstadio) 
    {
        this.idEstadio = idEstadio;
    }


    
    
    





}
