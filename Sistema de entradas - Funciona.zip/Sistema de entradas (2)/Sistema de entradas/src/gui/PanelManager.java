package gui;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class PanelManager extends JPanel {
    
    
    private CardLayout cardLayout;
    private Map<String,JPanel> paneles;

    public PanelManager()
    {
        cardLayout = new CardLayout();
        setLayout(cardLayout);
        paneles = new HashMap<>();

        PanelEstadios panelEstadios = new PanelEstadios();
        agregarPanel(panelEstadios, "Estadios");

        mostrarPanel("Inicio");
    }

    public void agregarPanel(JPanel panel, String nombre)
    {
        paneles.put(nombre,panel);
        add(panel,nombre);

    }

    public void mostrarPanel(String nombre)
    {
        cardLayout.show(this,nombre);
    }

 
}



