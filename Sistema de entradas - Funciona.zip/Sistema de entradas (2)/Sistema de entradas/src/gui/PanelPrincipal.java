package gui;

import javax.swing.*;

public class PanelPrincipal extends JFrame{

    private PanelManager panelManager;

    public PanelPrincipal()
    {
        setTitle("CocoTeck");
        setSize(900,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panelManager = new PanelManager();
        setContentPane(panelManager);

        crearMenu();

        setVisible(true);
    }

    private void crearMenu(){
        
        JMenuBar menuBar = new JMenuBar();

        JMenu menuAdmin = new JMenu("Administración");
        JMenuItem itemEstadios = new JMenuItem("Estadios");

        itemEstadios.addActionListener(e->panelManager.mostrarPanel("Estadios"));
        
        menuAdmin.add(itemEstadios);
        menuBar.add(menuAdmin);

        setJMenuBar(menuBar);

    }

    public static void main(String[] args) 
    {
        try
        {
        
            UIManager.LookAndFeelInfo[]estilos = UIManager.getInstalledLookAndFeels();
            int i = 0;
            boolean aplicado = false;
            while (i < estilos.length && !aplicado) {
                if("Nimbus".equals(estilos[i].getName()))
                {
                    UIManager.setLookAndFeel(estilos[i].getClassName());
                    aplicado = true;
                }
                i++;
                
            }

        }
        catch(Exception e)
        {

        }
        SwingUtilities.invokeLater(PanelPrincipal::new);
    }
}