package gui;

import entidades.Estadio;
import  dao.DaoEstadio;
import dao.DaoException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;


public class PanelEstadios extends JPanel {
    
    private JTextField txtNombre;
    private JTextField txtDireccion;
    private JButton btnGuardar;
    private JButton btnEliminar;
    private JTable tablaEstadios;
    private DaoEstadio daoEstadio;

    public PanelEstadios()
    {
      

        daoEstadio =  new DaoEstadio();

        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(15,15,15,15));
        setBackground(new Color(230,178,180));

        JLabel lblTitulo = new JLabel("Administración de estadios");
        lblTitulo.setFont(new Font("Segoe UI",Font.BOLD,20));
        lblTitulo.setBorder(new EmptyBorder(0,0,10,0));

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setOpaque(false);


        JPanel panelFormulario = new JPanel(new GridLayout(1, 2, 20, 0)); // 1 fila, 2 columnas
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Nuevo estadio"));
        panelFormulario.setOpaque(false);

        JPanel panelAlta = new JPanel(new GridBagLayout());
        panelAlta.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        txtNombre = new JTextField(20);
        txtNombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panelAlta.add(txtNombre, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Dirección:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtDireccion = new JTextField(20);
        txtDireccion.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panelAlta.add(txtDireccion, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setFocusPainted(false);
        btnGuardar.setPreferredSize(new Dimension(140, 30));
        panelAlta.add(btnGuardar, gbc);

        JPanel panelEliminar = new JPanel();
        panelEliminar.setOpaque(false);
        panelEliminar.setLayout(new BoxLayout(panelEliminar, BoxLayout.Y_AXIS));

        JLabel lblEliminar = new JLabel("<html><b>Eliminar estadio</b><br>" +"1. Seleccioná un estadio de la tabla.<br>" +
        "2. Hacé clic en <b>Eliminar</b>.</html>");
        lblEliminar.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnEliminar.setFocusPainted(false);
        btnEliminar.setPreferredSize(new Dimension(140, 30));
        btnEliminar.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelEliminar.add(Box.createVerticalStrut(10));
        panelEliminar.add(lblEliminar);
        panelEliminar.add(Box.createVerticalStrut(20));
        panelEliminar.add(btnEliminar);
        panelEliminar.add(Box.createVerticalGlue());

        panelFormulario.add(panelAlta);
        panelFormulario.add(panelEliminar);

        panelSuperior.add(lblTitulo,BorderLayout.NORTH);
        panelSuperior.add(panelFormulario,BorderLayout.CENTER);
        add(panelSuperior,BorderLayout.NORTH);

        tablaEstadios = new JTable();
        tablaEstadios.setFillsViewportHeight(true);
        tablaEstadios.setRowHeight(22);
        tablaEstadios.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));

        JScrollPane scroll  = new JScrollPane(tablaEstadios);
        scroll.setBorder(BorderFactory.createTitledBorder("Estadios"));
        add(scroll,BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardarEstadio());
        btnEliminar.addActionListener(e -> eliminarEstadio());

        panelSuperior.setBackground(getBackground());
        panelFormulario.setBackground(getBackground());


    cargarTabla();
    }


    private void guardarEstadio()
    {
        try
        {
            String nombre = txtNombre.getText();
            String direccion = txtDireccion.getText();
      

            Estadio estadio = new Estadio();
            estadio.setNombre(nombre);
            estadio.setDireccion(direccion);

            daoEstadio.insertar(estadio);

            JOptionPane.showMessageDialog(this,"Estadio guardado.");
            limpiarCampos();
            cargarTabla();

        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this, "Error al guardar."+e.getMessage());
        }
    }
    
    private void limpiarCampos()
    {
        txtNombre.setText("");
        txtDireccion.setText("");
    }

    private void cargarTabla()
    {
        try
        {
            List<Estadio> lista = daoEstadio.consultarTodos();
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("id");
            modelo.addColumn("Nombre");
            modelo.addColumn("Direccion");

            for(Estadio e : lista)
            {
                modelo.addRow(new Object[]
                {
                    e.getId(),
                    e.getNombre(),
                    e.getDireccion()

                });
            }

            tablaEstadios.setModel(modelo);

        }
        catch(DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al cargar."+e.getMessage());
        }
    }

    private void eliminarEstadio() 
    {
        int filaSeleccionada = tablaEstadios.getSelectedRow();
        if (filaSeleccionada == -1) 
        {
            JOptionPane.showMessageDialog(this, "Seleccioná un estadio para eliminar.");
            return;
        }
        int confirmacion = JOptionPane.showConfirmDialog(this,"¿Desea eliminar este estadio?","Confirmar",JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) 
        {
            try
            {
                int id = (int) tablaEstadios.getValueAt(filaSeleccionada, 0);
                daoEstadio.eliminar(id);
                JOptionPane.showMessageDialog(this, "Estadio eliminado correctamente.");
                cargarTabla();
            } 
            catch (DaoException e) 
            {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
            }
        }
    }

}
