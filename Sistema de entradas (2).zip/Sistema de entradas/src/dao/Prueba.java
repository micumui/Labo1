package dao;

import entidades.Espectaculo;
import entidades.Estadio;

public class Prueba {
    public static void main(String[] args) {

       /*  DaoEstadio dao = new DaoEstadio();

        try{
            Estadio estadio1 = new Estadio();
            estadio1.setNombre("Movistar arena");
            estadio1.setDireccion("Humboldt 450");
            dao.insertar(estadio1);
            System.out.println("Todo bien!!");

        }
        catch(DaoException e)
        {
            System.out.println("Error." + e.getMessage());
            e.printStackTrace();
        }
    }*/

        DaoEspectaculo dao  = new DaoEspectaculo();

        try{
            Espectaculo espectaculo1 = new Espectaculo();
            espectaculo1.setTitulo("Ameri Tour");
            espectaculo1.setPrecio(65000);
            dao.insertar(espectaculo1);
        }
        catch(DaoException e)
        {
            System.out.println("Error." + e.getMessage());
            e.printStackTrace();
        }
    }
}
