package dao;

import entidades.Espectaculo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoEspectaculo implements IDAO<Espectaculo>{

    
    private String DB_JDBC_DRIVER="org.h2.Driver";
    private String DB_URL="jdbc:h2:~/test";
    private String DB_USER="sa";
    private String DB_PASSWORD="";


    //Insertar en tabla
    @Override
    public void insertar(Espectaculo elemento) throws DaoException
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("se conecto");
            preparedStatement = connection.prepareStatement("INSERT INTO ESPECTACULO (TITULO,ESTADIO_ID,PRECIO_BASE) VALUES(?,?,?)");
            preparedStatement.setString(1, elemento.getTitulo()); 
            preparedStatement.setInt(2, elemento.getEstadioId());
            preparedStatement.setInt(3, elemento.getPrecio()); 

            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {

            throw  new DaoException("Fallo la base de datos." +e.getMessage());
        }

    }

    // Modificar en la tabala

    @Override
    public void modificar(Espectaculo elemento) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE ESPECTACULO SET TITULO=? PRECIO_BASE=? WHERE ID=?");
            preparedStatement.setString(1, elemento.getTitulo()); 
            preparedStatement.setInt(2, elemento.getPrecio());
            
            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw  new DaoException("Fallo la base de datos.");
        }
    }

    // Eliminar en la tabla

    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("DELETE FROM ESPECTACULO WHERE ID=?");
            preparedStatement.setInt(1, id);
            int resultado = preparedStatement.executeUpdate();
        }
        catch(ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Fallo la base de datos.");
        }

    }

    //Consultar de la tabla

    @Override
    public Espectaculo consultar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        Espectaculo espectaculo = new Espectaculo();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT * FROM ESPECTACULO WHERE ID=?");
            preparedStatement.setInt(1, id);
            ResultSet rs=preparedStatement.executeQuery();
            if (rs.next())
            {
                espectaculo.setId(rs.getInt("ID: "));
                espectaculo.setTitulo(rs.getString("Espectaculo:  "));
                espectaculo.setPrecio(rs.getInt("Precio:  "));
                espectaculo.setIdEstadio(rs.getInt("ID Estadio:  "));
            }
         }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta.");
        }
        return espectaculo;
    }


    //Consultar desde la tabla

    @Override
     public List<Espectaculo> consultarTodos() throws DaoException {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        List<Espectaculo> estadios = new ArrayList<>();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT * FROM ESPECTACULO");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next())
            {   Espectaculo espectaculo = new Espectaculo();
                espectaculo.setId(rs.getInt("ID: "));
                espectaculo.setTitulo(rs.getString("Espectaculo: "));
                espectaculo.setPrecio(rs.getInt("Precio: "));
                espectaculo.setIdEstadio(rs.getInt("ID Estadio:"));

                espectaculo.add(espectaculo);
            }
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta.");
        }
        return espectaculo;
    }
   
}
