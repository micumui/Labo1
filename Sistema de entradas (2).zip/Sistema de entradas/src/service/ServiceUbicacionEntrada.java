package service;

import dao.DaoException;
import entidades.UbicacionEntrada;

public class ServiceUbicacionEntrada {
    
    private DaoUbicacionEntrada daoUbicacionEntrada;

    public ServiceUbicacionEntrada()
    {
        daoUbicacionEntrada = new DaoUbicacionEntrada();
    }

    public void insertar(UbicacionEntrada ubicacionEntrada) throws ServiceException
    {
        try{
            daoUbicacionEntrada.insertar(ubicacionEntrada);
        }
        catch(DaoException e)
        {
            throw new ServiceException("Error en la base de datos. ");
        }

    }
    
}
