package service;

import dao.DaoException;
import entidades.Venta;

public class ServiceVenta {

    private DaoVenta daoVenta;

    public ServiceVenta()
    {
        daoVenta = new DaoVenta();
    }

    public void insertar(Venta venta) throws ServiceException
    {
        try{
            daoVenta.insertar(venta);
        }
        catch(DaoException e)
        {
            throw new ServiceException("Error en la base de datos. ");
        }

    }
}
