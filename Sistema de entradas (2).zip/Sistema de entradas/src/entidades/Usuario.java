package entidades;

public class Usuario {

    int id;
    String mail;
    String nombre;
    String contrasena;
    
    
    //Constructores
    public Usuario() 
    {
    }

    public Usuario(int id, String mail, String nombre, String contrasena) 
    {
        this.id = id;
        this.mail = mail;
        this.nombre = nombre;
        this.contrasena = contrasena;
    }


    //Getters
    public int getId() 
    {
        return id;
    }
    public String getMail() 
    {
        return mail;
    }
    public String getNombre()
    {
        return nombre;
    }
    public String getContrasena() 
    {
        return contrasena;
    }


    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setMail(String mail) 
    {
        this.mail = mail;
    }
    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }
    public void setContrasena(String contrasena) 
    {
        this.contrasena = contrasena;
    }
    
}
