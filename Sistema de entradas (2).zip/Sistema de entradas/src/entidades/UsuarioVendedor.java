package entidades;

public class UsuarioVendedor extends Usuario {
    
    String tipoUsuario;

    public UsuarioVendedor(String tipoUsuario) 
    {
        this.tipoUsuario = "Vendedor";
    }

    public UsuarioVendedor(int id, String mail, String nombre, String contrasena, String tipoUsuario) 
    {
        super(id, mail, nombre, contrasena);
        this.tipoUsuario = "Vendedor";
    }

    public void setTipoUsuario(String tipoUsuario) 
    {
        this.tipoUsuario = tipoUsuario;
    }

    public String getTipoUsuario() 
    {
        return tipoUsuario;
    }

}
