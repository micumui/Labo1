package entidades;

public class UsuarioAdmin extends Usuario {
    
    String tipoUsuario;

    //Constructores
    public UsuarioAdmin(String tipoUsuario) 
    {
        this.tipoUsuario = "Administrador";
    }

    public UsuarioAdmin(int id, String mail, String nombre, String contrasena, String tipoUsuario) 
    {
        super(id, mail, nombre, contrasena);
        this.tipoUsuario = "Administrador";
    }

    public String getTipoUsuario() 
    {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) 
    {
        this.tipoUsuario = tipoUsuario;
    }


    
    
    




}
