package entidades;

public class UsuarioCliente extends Usuario{
    
    String tipoUsuario;

    public UsuarioCliente(String tipoUsuario) {
        this.tipoUsuario = "Cliente";
    }

    public UsuarioCliente(int id, String mail, String nombre, String contrasena, String tipoUsuario) {
        super(id, mail, nombre, contrasena);
        this.tipoUsuario = "Cliente";
    }

    public String getTipoUsuario() 
    {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) 
    {
        this.tipoUsuario = tipoUsuario;
    }

    
    

    
}
