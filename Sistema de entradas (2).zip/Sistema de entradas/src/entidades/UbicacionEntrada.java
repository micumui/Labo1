package entidades;

public class UbicacionEntrada {
    
    int id;
    int capacidad;
    float precio;
    String nombreUbicacion;

    //Constructores
    public UbicacionEntrada() 
    {
    }

    public UbicacionEntrada(int id, int capacidad, float precio, String nombreUbicacion) 
    {
        this.id = id;
        this.capacidad = capacidad;
        this.precio = precio;
        this.nombreUbicacion = nombreUbicacion;
    }

    //Getters
    public int getId() 
    {
        return id;
    }

    public int getCapacidad() 
    {
        return capacidad;
    }
    public float getPrecio() 
    {
        return precio;
    }
    public String getNombreUbicacion() 
    {
        return nombreUbicacion;
    }

    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setCapacidad(int capacidad) 
    {
        this.capacidad = capacidad;
    }
    public void setPrecio(float precio) 
    {
        this.precio = precio;
    }
    public void setNombreUbicacion(String nombreUbicacion) 
    {
        this.nombreUbicacion = nombreUbicacion;
    }

}
