package gui;

import dao.DaoException;
import dao.DaoVenta;
import entidades.Espectaculo;
import entidades.UbicacionEntrada;
import entidades.Usuario;
import entidades.Venta;
import service.ServiceEspectaculo;
import service.ServiceException;
import service.ServiceUbicacionEntrada;
import service.ServiceUsuario;
import service.ServiceVenta;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class PanelVentas extends JPanel {

    private final Usuario vendedorLogueado;

    private JComboBox<Usuario> cbCliente;
    private JComboBox<Espectaculo> cbEspectaculo;
    private JComboBox<UbicacionEntrada> cbUbicacion;

    private JLabel lblTituloValor;
    private JLabel lblFechaValor;
    private JLabel lblPrecioValor;

    private JSpinner spCantidad;
    private JTextField txtTotal;

    private JButton btnRegistrar;

    private JTable tablaVentas;
    private DefaultTableModel modeloTabla;

    private DaoVenta daoVenta;
    private ServiceVenta serviceVenta;
    private ServiceUsuario serviceUsuario;
    private ServiceEspectaculo serviceEspectaculo;
    private ServiceUbicacionEntrada serviceUbicacionEntrada;

    private final SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public PanelVentas(Usuario vendedorLogueado) {

        this.vendedorLogueado = vendedorLogueado;
        daoVenta = new DaoVenta();

        serviceVenta = new ServiceVenta();
        serviceUsuario = new ServiceUsuario();
        serviceEspectaculo = new ServiceEspectaculo();
        serviceUbicacionEntrada = new ServiceUbicacionEntrada();

        Color rosaSuave = new Color(244, 205, 210);
        Color grisBorde = new Color(230, 230, 230);
        Color azulTitulo = new Color(5, 51, 66);

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblTitulo = new JLabel("Registro de ventas");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(Color.WHITE);
        panelFormulario.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(grisBorde),"Registrar nueva venta"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int fila = 0;

        cbCliente = new JComboBox<>();
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Cliente:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(cbCliente, gbc);
        fila++;

        cbEspectaculo = new JComboBox<>();
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Espectáculo:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(cbEspectaculo, gbc);
        fila++;

        lblTituloValor = new JLabel("-");
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(lblTituloValor, gbc);
        fila++;

        lblFechaValor = new JLabel("-");
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Fecha y hora:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(lblFechaValor, gbc);
        fila++;

        lblPrecioValor = new JLabel("-");
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Precio base:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(lblPrecioValor, gbc);
        fila++;

        cbUbicacion = new JComboBox<>();
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Ubicación:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(cbUbicacion, gbc);
        fila++;

        spCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 50, 1));
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Cantidad:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(spCantidad, gbc);
        fila++;

        txtTotal = new JTextField(10);
        txtTotal.setEditable(false);
        gbc.gridx = 0; gbc.gridy = fila;
        panelFormulario.add(new JLabel("Total:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(txtTotal, gbc);
        fila++;

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(Color.WHITE);

        btnRegistrar = new JButton("Registrar venta");
        btnRegistrar.setBackground(rosaSuave);

        panelBotones.add(btnRegistrar);

        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.setBackground(Color.WHITE);
        panelIzquierdo.add(panelFormulario, BorderLayout.CENTER);
        panelIzquierdo.add(panelBotones, BorderLayout.SOUTH);

        add(panelIzquierdo, BorderLayout.WEST);

        modeloTabla = new DefaultTableModel(
                new Object[]{"ID", "Fecha/Hora", "Cliente", "Vendedor","Espectáculo", "Ubicación", "Total", "Cantidad"}, 0)
        {
            @Override public boolean isCellEditable(int row,int col){return false;}
        };

        tablaVentas = new JTable(modeloTabla);

        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        tablaVentas.getColumnModel().getColumn(6).setCellRenderer(right);
        tablaVentas.getColumnModel().getColumn(7).setCellRenderer(right);

        JScrollPane scrollTabla = new JScrollPane(tablaVentas);
        scrollTabla.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(grisBorde),"Ventas registradas"));
        add(scrollTabla, BorderLayout.CENTER);

        cargarClientes();
        cargarEspectaculos();
        configurarRenderers();
        actualizarDetalleEspectaculo();
        cargarVentas();
        configurarEventos();
    }


    private void cargarClientes()
    {
        try
        {
            cbCliente.removeAllItems();
            List<Usuario> clientes = serviceUsuario.listarClientes();
            for (Usuario u : clientes) cbCliente.addItem(u);
        } 
        catch (ServiceException e) {
            JOptionPane.showMessageDialog(this,"Error al cargar clientes: "+e.getMessage());
        }
    }

    private void cargarEspectaculos() 
    {
        try 
        {
            cbEspectaculo.removeAllItems();
            List<Espectaculo> espectaculos = serviceEspectaculo.listarEspectaculos();
            for (Espectaculo e : espectaculos) cbEspectaculo.addItem(e);
        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());
        }
    }

    private void cargarUbicacionesParaEspectaculo(Espectaculo e) 
    {
        cbUbicacion.removeAllItems();
        if (e == null) return;
        try 
        {
            var ubic = serviceUbicacionEntrada.listarPorEstadio(e.getEstadio().getId());
            for (UbicacionEntrada u : ubic) cbUbicacion.addItem(u);
        } 
        catch (DaoException ex) 
        {
            JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());
        }
    }

    private void configurarRenderers() 
    {
        cbEspectaculo.setRenderer(new DefaultListCellRenderer()
        {
            @Override public Component getListCellRendererComponent(JList<?> list,Object value,int idx,boolean sel,boolean focus)
            {
                super.getListCellRendererComponent(list,value,idx,sel,focus);
                if (value instanceof Espectaculo e) setText(e.getTitulo());
                return this;
            }
        });

        cbCliente.setRenderer(new DefaultListCellRenderer(){
            @Override public Component getListCellRendererComponent(JList<?> list,Object value,int idx,boolean sel,boolean focus)
            {
                super.getListCellRendererComponent(list,value,idx,sel,focus);
                if (value instanceof Usuario u) setText(u.getNombre()+" ("+u.getMail()+")");
                return this;
            }
        });
    }

    private void cargarVentas() 
    {
        try 
        {
            modeloTabla.setRowCount(0);
            List<Venta> ventas = serviceVenta.listarVentas();

            for (Venta v : ventas) {
                modeloTabla.addRow(new Object[]{
                        v.getId(),
                        (v.getFechaHora()!=null? formatoFecha.format(v.getFechaHora()) : "-"),
                        v.getCliente()!=null? v.getCliente().getNombre() : "-",
                        v.getVendedor()!=null? v.getVendedor().getNombre() : "-",
                        v.getEspectaculo()!=null? v.getEspectaculo().getTitulo() : "-",
                        v.getUbicacion()!=null? v.getUbicacion().getnombre() : "-",
                        v.getTotal(),
                        v.getCantidad()
                });
            }

        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar ventas: "+e.getMessage());
        }
    }

    private void configurarEventos() 
    {
        cbEspectaculo.addActionListener(e -> actualizarDetalleEspectaculo());
        cbUbicacion.addActionListener(e -> recalcularTotal());  
        spCantidad.addChangeListener(e -> recalcularTotal());
        btnRegistrar.addActionListener(e -> registrarVenta());
    }

    private void actualizarDetalleEspectaculo() 
    {
        Espectaculo e = (Espectaculo) cbEspectaculo.getSelectedItem();

        if (e == null) 
        {
            lblTituloValor.setText("-");
            lblFechaValor.setText("-");
            lblPrecioValor.setText("-");
            txtTotal.setText("");
            cbUbicacion.removeAllItems();
            return;
        }

        lblTituloValor.setText(e.getTitulo());
        lblFechaValor.setText(e.getFechaHora()!=null? formatoFecha.format(e.getFechaHora()) : "-");
        lblPrecioValor.setText(String.valueOf(e.getPrecio()));

        cargarUbicacionesParaEspectaculo(e);
        recalcularTotal();
    }

    private void recalcularTotal()
    {
        Espectaculo espectaculo = (Espectaculo) cbEspectaculo.getSelectedItem();
        UbicacionEntrada ubicacion = (UbicacionEntrada) cbUbicacion.getSelectedItem();

        if (espectaculo == null || ubicacion == null)
        {
            txtTotal.setText("");
            lblPrecioValor.setText("-");
            return;
        }

        int cantidad = (int) spCantidad.getValue();
        try
        {
            float total = serviceVenta.calcularTotalPorUbicacion(ubicacion, cantidad);
            txtTotal.setText(String.valueOf(total));
            lblPrecioValor.setText(String.valueOf(ubicacion.getPrecio()));
        }
        catch (DaoException ex)
        {
            JOptionPane.showMessageDialog(this,"Error: " + ex.getMessage());
        }
    }


    private void registrarVenta()
    {
        try
        {
            int filaSeleccionada = tablaVentas.getSelectedRow();
            if (filaSeleccionada == -1) 
            {
                JOptionPane.showMessageDialog(this,"Debe seleccionar una venta de la tabla para asignarla al vendedor.","Ninguna venta seleccionada",JOptionPane.WARNING_MESSAGE);
                return;
            }

            Object idObj = modeloTabla.getValueAt(filaSeleccionada, 0);
            int ventaId;

            if (idObj instanceof Integer) 
            {
                ventaId = (Integer) idObj;
            } 
            else
            {
                ventaId = Integer.parseInt(idObj.toString());
            }

            int vendedorId = vendedorLogueado.getId();
            daoVenta.actualizarVendedor(ventaId, vendedorId);


            modeloTabla.setValueAt(vendedorLogueado.getNombre(), filaSeleccionada, 3); 

            JOptionPane.showMessageDialog(this,"Venta asignada correctamente al vendedor " + vendedorLogueado.getNombre());

        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al registrar la venta: " + e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE
            );
        }
    }

}
