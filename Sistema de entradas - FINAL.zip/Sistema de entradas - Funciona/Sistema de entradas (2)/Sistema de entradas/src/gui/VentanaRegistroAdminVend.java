package gui;

import entidades.Usuario;
import entidades.Rol;
import service.ServiceException;
import service.ServiceUsuario;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistroAdminVend extends JFrame {

    private JTextField txtNombre;
    private JTextField txtMail;
    private JComboBox<String> comboRol;
    private JButton btnCrear;

    private ServiceUsuario serviceUsuario;

    public VentanaRegistroAdminVend() 
    {

        serviceUsuario = new ServiceUsuario();

        setTitle("Crear cuenta administrador / vendedor");
        setSize(420, 260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color rosaSuave = new Color(244, 205, 210);
        Color azulTitulo = new Color(5, 51, 66);

        JLabel lblTitulo = new JLabel("Crear cuenta administradores");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.setBackground(Color.WHITE);
        panelCentro.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nombre
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtNombre = new JTextField();
        panelCentro.add(txtNombre, gbc);

        // Mail
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Mail:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtMail = new JTextField();
        panelCentro.add(txtMail, gbc);

        // Rol
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Rol:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        comboRol = new JComboBox<>(new String[] {"ADMINISTRADOR","VENDEDOR"});
        panelCentro.add(comboRol, gbc);

        add(panelCentro, BorderLayout.CENTER);

        JPanel panelSur = new JPanel();
        panelSur.setBackground(rosaSuave);
        panelSur.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblInfo = new JLabel("La clave será una por defecto según el rol.");
        panelSur.add(lblInfo);

        btnCrear = new JButton("Crear cuenta");
        panelSur.add(btnCrear);

        add(panelSur, BorderLayout.SOUTH);

        btnCrear.addActionListener(e -> registrarAdminOVendedor());
    }

    private void registrarAdminOVendedor() 
    {
        String nombre = txtNombre.getText().trim();
        String mail = txtMail.getText().trim();
        String rolSeleccionado = (String) comboRol.getSelectedItem();

        if (nombre.isEmpty() || mail.isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Completá nombre y mail.");
            return;
        }

        try 
        {
            Usuario u = serviceUsuario.registrarAdminOVendedor(nombre, mail, rolSeleccionado);

            JOptionPane.showMessageDialog(this,"Cuenta creada.\nMail: " + u.getMail() +"\nRol: " + u.getRol().getNombre() +"\nClave por defecto: " + u.getClave());
            dispose();

        } 
        catch (ServiceException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al crear usuario: " + e.getMessage());
        }
    }
}
