package gui;

import entidades.Estadio;
import dao.DaoEstadio;
import dao.DaoException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelEstadios extends JPanel {

    private JTextField txtNombre;
    private JTextField txtDireccion;
    private JTextField txtCapacidad;
    private JTextField txtRutaFoto;

    private JButton btnGuardar;
    private JButton btnEliminar;
    private JButton btnModificar;
    private JButton btnSeleccionarFoto;

    private JLabel lblFotoPreview;

    private JTable tablaEstadios;
    private DefaultTableModel modeloTabla;

    private DaoEstadio daoEstadio;
    private Long estadioSeleccionadoId = null;

    public PanelEstadios() {

        daoEstadio = new DaoEstadio();

        Color rosaSuave = new Color(244, 205, 210);
        Color grisBorde = new Color(230, 230, 230);
        Color azulTitulo = new Color(5, 51, 66);

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Administración de estadios");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        add(panelTitulo, BorderLayout.NORTH);
        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BoxLayout(panelFormulario, BoxLayout.X_AXIS));
        panelFormulario.setBackground(rosaSuave);
        panelFormulario.setBorder(new EmptyBorder(15, 15, 15, 15));

     
        JPanel panelAlta = new JPanel(new GridBagLayout());
        panelAlta.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int fila = 0;

    
        gbc.gridx = 0;
        gbc.gridy = fila++;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel lblNuevo = new JLabel("Nuevo estadio");
        lblNuevo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblNuevo.setForeground(azulTitulo);
        panelAlta.add(lblNuevo, gbc);

        gbc.gridwidth = 1;

        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtNombre = new JTextField(20);
        txtNombre.setBorder(BorderFactory.createLineBorder(grisBorde));
        panelAlta.add(txtNombre, gbc);
        fila++;

 
        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Dirección:"), gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtDireccion = new JTextField(20);
        txtDireccion.setBorder(BorderFactory.createLineBorder(grisBorde));
        panelAlta.add(txtDireccion, gbc);
        fila++;

        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Capacidad:"), gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtCapacidad = new JTextField(10);
        txtCapacidad.setBorder(BorderFactory.createLineBorder(grisBorde));
        panelAlta.add(txtCapacidad, gbc);
        fila++;


        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Foto estadio:"), gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        txtRutaFoto = new JTextField(20);
        txtRutaFoto.setEditable(false);
        txtRutaFoto.setBorder(BorderFactory.createLineBorder(grisBorde));
        panelAlta.add(txtRutaFoto, gbc);
        fila++;

    
        gbc.gridy = fila;
        gbc.gridx = 1;
        btnSeleccionarFoto = new JButton("Seleccionar foto");
        panelAlta.add(btnSeleccionarFoto, gbc);
        fila++;
    
        gbc.gridy = fila;
        gbc.gridx = 1;
        lblFotoPreview = new JLabel("Sin foto");
        lblFotoPreview.setPreferredSize(new Dimension(200, 150));
        lblFotoPreview.setHorizontalAlignment(SwingConstants.CENTER);
        lblFotoPreview.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        panelAlta.add(lblFotoPreview, gbc);
        fila++;

  
        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        btnGuardar = new JButton("Guardar");
        btnGuardar.setPreferredSize(new Dimension(140, 30));
        panelAlta.add(btnGuardar, gbc);
        fila++;

        gbc.gridy = fila;
        btnModificar = new JButton("Modificar");
        btnModificar.setPreferredSize(new Dimension(140, 30));
        panelAlta.add(btnModificar, gbc);
        fila++;

        JPanel panelEliminar = new JPanel();
        panelEliminar.setOpaque(false);
        panelEliminar.setLayout(new BoxLayout(panelEliminar, BoxLayout.Y_AXIS));
        panelEliminar.setBorder(new EmptyBorder(10, 20, 10, 10));

        JLabel lblEliminarTitulo = new JLabel("Eliminar estadio");
        lblEliminarTitulo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblEliminarTitulo.setForeground(azulTitulo);
        lblEliminarTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblEliminar = new JLabel("<html>1. Seleccioná un estadio de la tabla.<br>2. Hacé clic en <b>Eliminar</b>.</html>");
        lblEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblEliminar.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnEliminar.setFocusPainted(false);
        btnEliminar.setPreferredSize(new Dimension(140, 30));
        btnEliminar.setMaximumSize(new Dimension(160, 32));
        btnEliminar.setBackground(new Color(255, 245, 245));
        btnEliminar.setBorder(BorderFactory.createLineBorder(new Color(180, 140, 140), 1));
        btnEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelEliminar.add(lblEliminarTitulo);
        panelEliminar.add(Box.createVerticalStrut(8));
        panelEliminar.add(lblEliminar);
        panelEliminar.add(Box.createVerticalStrut(20));
        panelEliminar.add(btnEliminar);
        panelEliminar.add(Box.createVerticalGlue());

 
        panelFormulario.add(panelAlta);
        panelFormulario.add(Box.createHorizontalStrut(20));
        panelFormulario.add(panelEliminar);

   
        modeloTabla = new DefaultTableModel(new Object[]{"id", "Nombre", "Direccion", "Capacidad"}, 0);
        tablaEstadios = new JTable(modeloTabla);
        tablaEstadios.setFillsViewportHeight(true);
        tablaEstadios.setRowHeight(22);
        tablaEstadios.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tablaEstadios.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tablaEstadios.getTableHeader().setBackground(new Color(245, 245, 245));
        tablaEstadios.getTableHeader().setForeground(new Color(80, 80, 80));

        JScrollPane scroll = new JScrollPane(tablaEstadios);
        scroll.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(grisBorde, 1),new EmptyBorder(5, 5, 5, 5)));
        scroll.getViewport().setBackground(Color.WHITE);

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setOpaque(false);
        JLabel lblTabla = new JLabel("Estadios");
        lblTabla.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTabla.setForeground(azulTitulo);
        lblTabla.setBorder(new EmptyBorder(5, 0, 5, 0));
        panelTabla.add(lblTabla, BorderLayout.NORTH);
        panelTabla.add(scroll, BorderLayout.CENTER);


        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelFormulario, panelTabla);
        split.setResizeWeight(0.35);
        split.setDividerSize(6);
        split.setBorder(null);

        add(split, BorderLayout.CENTER);

      
        tablaEstadios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaEstadios.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                modificarEstadio();
            }
        });

        btnGuardar.addActionListener(e -> guardarEstadio());
        btnEliminar.addActionListener(e -> eliminarEstadio());
        btnModificar.addActionListener(e -> modificarEstadio());
        btnSeleccionarFoto.addActionListener(e -> seleccionarFotoEstadio());

  
        cargarTabla();
    }

    private void guardarEstadio() 
    {
        try 
        {
            String nombre = txtNombre.getText();
            String direccion = txtDireccion.getText();
            int capacidad = Integer.parseInt(txtCapacidad.getText());
            String rutaFoto = txtRutaFoto.getText();

            Estadio estadio = new Estadio();
            estadio.setNombre(nombre);
            estadio.setDireccion(direccion);
            estadio.setCapacidad(capacidad);
            estadio.setFotoEstadio(rutaFoto);

            if (estadioSeleccionadoId == null) 
            {
                daoEstadio.insertar(estadio);
                JOptionPane.showMessageDialog(this, "Estadio guardado correctamente.");
            } 
            else 
            {
                estadio.setId(estadioSeleccionadoId.intValue());
                daoEstadio.modificar(estadio);
                JOptionPane.showMessageDialog(this, "Estadio modificado correctamente.");
            }
            limpiarCampos();
            cargarTabla();

        } catch (DaoException e) {
            JOptionPane.showMessageDialog(this, "Error." + e.getMessage());
        }
    }

    private void limpiarCampos() 
    {
        txtNombre.setText("");
        txtDireccion.setText("");
        txtCapacidad.setText("");
        txtRutaFoto.setText("");
        lblFotoPreview.setIcon(null);
        lblFotoPreview.setText("Sin foto");
        estadioSeleccionadoId = null;
        btnGuardar.setText("Guardar");
        tablaEstadios.clearSelection();
    }

    private void cargarTabla() 
    {
        try {
            List<Estadio> lista = daoEstadio.consultarTodos();
            modeloTabla.setRowCount(0);

            for (Estadio e : lista) {
                modeloTabla.addRow(new Object[]{
                        e.getId(),
                        e.getNombre(),
                        e.getDireccion(),
                        e.getCapacidad()
                });
            }
            modeloTabla.fireTableDataChanged();

        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar. " + e.getMessage());
        }
    }

    private void modificarEstadio() 
    {
        int fila = tablaEstadios.getSelectedRow();
        if (fila == -1) 
        {
            return;
        }

        Object valorId = tablaEstadios.getValueAt(fila, 0);
        if (valorId instanceof Number) 
        {
            estadioSeleccionadoId = ((Number) valorId).longValue();
        } 
        else 
        {
            estadioSeleccionadoId = Long.parseLong(valorId.toString());
        }

        try 
        {
            Estadio estadio = daoEstadio.consultar(estadioSeleccionadoId.intValue());
            txtNombre.setText(estadio.getNombre());
            txtDireccion.setText(estadio.getDireccion());
            txtCapacidad.setText(String.valueOf(estadio.getCapacidad()));
            txtRutaFoto.setText(estadio.getFotoEstadio());
            mostrarFotoEnLabel(estadio.getFotoEstadio(), lblFotoPreview);

            btnGuardar.setText("Modificar");

        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar estadio: " + e.getMessage());
        }
    }

    private void eliminarEstadio() 
    {
        int filaSeleccionada = tablaEstadios.getSelectedRow();
        if (filaSeleccionada == -1) 
        {
            JOptionPane.showMessageDialog(this, "Seleccioná un estadio para eliminar.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,"¿Desea eliminar este estadio?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) 
        {
            try 
            {
                int id = (int) tablaEstadios.getValueAt(filaSeleccionada, 0);
                daoEstadio.eliminar(id);
                JOptionPane.showMessageDialog(this, "Estadio eliminado correctamente.");
                cargarTabla();
            } 
            catch (DaoException e) 
            {
                JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
            }
        }
    }

    private void seleccionarFotoEstadio() 
    {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int opcion = chooser.showOpenDialog(this);
        if (opcion == JFileChooser.APPROVE_OPTION) 
        {
            String ruta = chooser.getSelectedFile().getAbsolutePath();
            txtRutaFoto.setText(ruta);
            mostrarFotoEnLabel(ruta, lblFotoPreview);
        }
    }

    private void mostrarFotoEnLabel(String ruta, JLabel label) 
    {
        if (ruta == null || ruta.isEmpty()) 
        {
            label.setIcon(null);
            label.setText("Sin foto");
            return;
        }
        ImageIcon icon = new ImageIcon(ruta);
        Image img = icon.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_SMOOTH);
        label.setText("");
        label.setIcon(new ImageIcon(img));
    }
}
