package gui;

import dao.DaoEspectaculo;
import dao.DaoException;
import entidades.Espectaculo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class PanelListadoEspectaculos extends JPanel {

    private JTable tablaEspectaculos;
    private DefaultTableModel modeloTabla;
    private DaoEspectaculo daoEspectaculo;

    public PanelListadoEspectaculos() {

        daoEspectaculo = new DaoEspectaculo();

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Listado de espectáculos");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        add(lblTitulo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Estadio", "Título", "Fecha/Hora", "Precio base"}, 0) 
        {
            @Override
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };

        tablaEspectaculos = new JTable(modeloTabla);
        tablaEspectaculos.setRowHeight(22);
        tablaEspectaculos.getTableHeader().setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(tablaEspectaculos);
        add(scroll, BorderLayout.CENTER);

        cargarTabla();
    }

    private void cargarTabla() 
    {
        modeloTabla.setRowCount(0);
        try 
        {
            List<Espectaculo> lista = daoEspectaculo.consultarTodos();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            for (Espectaculo e : lista) 
            {
                String nombreEstadio = (e.getEstadio() != null) ? e.getEstadio().getNombre() : "";
                String fechaStr = (e.getFechaHora() != null) ? sdf.format(e.getFechaHora()) : "";
                modeloTabla.addRow(new Object[]{
                        e.getId(),
                        nombreEstadio,
                        e.getTitulo(),
                        fechaStr,
                        e.getPrecio()
                });
            }
        } catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al cargar espectáculos: " + e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}






    

