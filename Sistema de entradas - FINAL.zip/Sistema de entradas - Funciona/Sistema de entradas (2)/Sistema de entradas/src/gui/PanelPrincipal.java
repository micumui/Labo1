package gui;

import javax.swing.*;

import entidades.Usuario;

import java.awt.*;

public class PanelPrincipal extends JFrame {

    private PanelManager panelManager;
    Usuario usuarioLogueado;
        

    public PanelPrincipal(Usuario usuarioLogueado) {

        //A que puede acceder cada tipo de usuario
        this.usuarioLogueado = usuarioLogueado;
        String nombreRol = (usuarioLogueado.getRol() != null) ? usuarioLogueado.getRol().getNombre() : "";
        boolean esAdmin = "ADMINISTRADOR".equalsIgnoreCase(nombreRol);
        boolean esVendedor = "VENDEDOR".equalsIgnoreCase(nombreRol);
        boolean esCliente = "CLIENTE".equalsIgnoreCase(nombreRol);

        setTitle("CocoTeck - Usuario: " + usuarioLogueado.getNombre() +" (" + usuarioLogueado.getRol().getNombre() + ")");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
  

        
        setTitle("CocoTeck");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        JPanel barra = new JPanel();
        barra.setBackground(new Color(244, 170, 190)); // tu rosa viejo
        barra.setLayout(new FlowLayout(FlowLayout.CENTER, 40, 10));

        JButton btnEstadios      = crearBotonMenu("Estadios");
        JButton btnUbicaciones   = crearBotonMenu("Ubicaciones");
        JButton btnEspectaculos  = crearBotonMenu("Espectáculos");
        JButton btnEntradas      = crearBotonMenu("Entradas");

        barra.add(btnEstadios);
        barra.add(btnUbicaciones);
        barra.add(btnEspectaculos);
        barra.add(btnEntradas);

        add(barra, BorderLayout.NORTH);

        panelManager = new PanelManager(usuarioLogueado);
        add(panelManager, BorderLayout.CENTER);

        //Estadios
        JPopupMenu menuEstadios = new JPopupMenu();
        JMenuItem itemEstVer   = new JMenuItem("Ver estadios");
        menuEstadios.add(itemEstVer);
        btnEstadios.addActionListener(e ->menuEstadios.show(btnEstadios, 0, btnEstadios.getHeight()));
        itemEstVer.addActionListener(e ->panelManager.mostrarPanel("EstadiosVer"));
        if(esAdmin)
        {
        
            JMenuItem itemEstAdmin = new JMenuItem("Administración");
            menuEstadios.add(itemEstAdmin);
            itemEstAdmin.addActionListener(e ->panelManager.mostrarPanel("EstadiosAdmin"));
        }

        //Ubicaciones
        JPopupMenu menuUbic = new JPopupMenu();
        JMenuItem itemUbicVer   = new JMenuItem("Ver ubicaciones");
        menuUbic.add(itemUbicVer);
        btnUbicaciones.addActionListener(e ->menuUbic.show(btnUbicaciones, 0, btnUbicaciones.getHeight()));
        itemUbicVer.addActionListener(e ->panelManager.mostrarPanel("UbicacionesVer"));
        if(esAdmin)
        {
            JMenuItem itemUbicAdmin = new JMenuItem("Administración");
            menuUbic.add(itemUbicAdmin);
            itemUbicAdmin.addActionListener(e ->panelManager.mostrarPanel("UbicacionesAdmin"));
        }

        //Especrtaculos
        JPopupMenu menuEsp = new JPopupMenu();
        JMenuItem itemEspVer   = new JMenuItem("Ver espectáculos");
        menuEsp.add(itemEspVer);
        btnEspectaculos.addActionListener(e ->menuEsp.show(btnEspectaculos, 0, btnEspectaculos.getHeight()));
        itemEspVer.addActionListener(e ->panelManager.mostrarPanel("EspectaculosVer"));
        if(esAdmin)
        {
        JMenuItem itemEspAdmin = new JMenuItem("Administración");
        menuEsp.add(itemEspAdmin);
        itemEspAdmin.addActionListener(e ->panelManager.mostrarPanel("EspectaculosAdmin"));
        }
        
        if (esAdmin || esVendedor)
        {
            JMenuItem itemReporte = new JMenuItem("Reporte de ventas");
            menuEsp.add(itemReporte);
            itemReporte.addActionListener(e -> panelManager.mostrarPanel("ReporteVentas"));
        }

        if (esAdmin || esVendedor) 
        {
            btnEntradas.addActionListener(e -> panelManager.mostrarPanel("Ventas"));
        } 
        else if (esCliente) 
        {
            btnEntradas.addActionListener(e -> panelManager.mostrarPanel("EntradasCliente"));
        }

        if (esCliente) 
        {
            panelManager.mostrarPanel("EntradasCliente");
        }
    }

    private JButton crearBotonMenu(String texto) 
    {
        JButton btn = new JButton(texto);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setForeground(Color.DARK_GRAY);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
