package gui;

import dao.DaoException;
import entidades.Espectaculo;
import entidades.UbicacionEntrada;
import entidades.Usuario;
import entidades.Venta;
import service.ServiceEspectaculo;
import service.ServiceUbicacionEntrada;
import service.ServiceVenta;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class PanelEntradasCliente extends JPanel {

    private final Usuario usuarioLogueado;

    private JComboBox<Espectaculo> cbEspectaculo;
    private JComboBox<UbicacionEntrada> cbUbicacion;

    private JLabel lblTituloValor;
    private JLabel lblFechaValor;
    private JLabel lblPrecioValor;

    private JSpinner spCantidad;
    private JTextField txtTotal;

    private JButton btnComprar;
    private JButton btnDevolver;

    private JTable tablaVentas;
    private DefaultTableModel modeloTabla;

    private ServiceVenta serviceVenta;
    private ServiceEspectaculo serviceEspectaculo;
    private ServiceUbicacionEntrada serviceUbicacion;


    private JLabel lblPosterEspectaculo;
    private JLabel lblFotoEstadio;

    private final SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public PanelEntradasCliente(Usuario usuarioLogueado)
    {
        this.usuarioLogueado = usuarioLogueado;

        serviceVenta = new ServiceVenta();
        serviceEspectaculo = new ServiceEspectaculo();
        serviceUbicacion = new ServiceUbicacionEntrada();

        Color rosaSuave = new Color(244, 205, 210);
        Color grisBorde = new Color(230, 230, 230);
        Color azulTitulo = new Color(5, 51, 66);

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblTitulo = new JLabel("Mis entradas");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(Color.WHITE);
        panelFormulario.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(grisBorde),"Comprar entrada"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int fila = 0;

        cbEspectaculo = new JComboBox<>();
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Espectáculo:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(cbEspectaculo, gbc);
        fila++;

        lblTituloValor = new JLabel("-");
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(lblTituloValor, gbc);
        fila++;

        lblFechaValor = new JLabel("-");
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Fecha y hora:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(lblFechaValor, gbc);
        fila++;

        lblPrecioValor = new JLabel("-");
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Precio base:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(lblPrecioValor, gbc);
        fila++;

        cbUbicacion = new JComboBox<>();
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Ubicación:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(cbUbicacion, gbc);
        fila++;

        spCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Cantidad:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(spCantidad, gbc);
        fila++;

        txtTotal = new JTextField(10);
        txtTotal.setEditable(false);
        gbc.gridx = 0;
        gbc.gridy = fila;
        panelFormulario.add(new JLabel("Total:"), gbc);
        gbc.gridx = 1;
        panelFormulario.add(txtTotal, gbc);
        fila++;

   
        lblPosterEspectaculo = new JLabel("Sin poster");
        lblPosterEspectaculo.setHorizontalAlignment(SwingConstants.CENTER);
        lblPosterEspectaculo.setPreferredSize(new Dimension(220, 160));
        lblPosterEspectaculo.setBorder(BorderFactory.createLineBorder(grisBorde));

        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.BOTH;
        panelFormulario.add(lblPosterEspectaculo, gbc);
        fila++;

        lblFotoEstadio = new JLabel("Sin foto estadio");
        lblFotoEstadio.setHorizontalAlignment(SwingConstants.CENTER);
        lblFotoEstadio.setPreferredSize(new Dimension(220, 160));
        lblFotoEstadio.setBorder(BorderFactory.createLineBorder(grisBorde));

        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 2;
        panelFormulario.add(lblFotoEstadio, gbc);
        fila++;

        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(Color.WHITE);

        btnComprar = new JButton("Comprar");
        btnComprar.setBackground(rosaSuave);

        btnDevolver = new JButton("Devolver entrada");
        btnDevolver.setBackground(rosaSuave);

        panelBotones.add(btnComprar);
        panelBotones.add(btnDevolver);

        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.setBackground(Color.WHITE);
        panelIzquierdo.add(panelFormulario, BorderLayout.CENTER);
        panelIzquierdo.add(panelBotones, BorderLayout.SOUTH);

        add(panelIzquierdo, BorderLayout.WEST);

        modeloTabla = new DefaultTableModel(
                new Object[]{"ID", "Fecha/Hora", "Espectáculo", "Ubicación", "Total","Cantidad"}, 0)
        {
            @Override
            public boolean isCellEditable(int row, int column)
            {
                return false;
            }
        };

        tablaVentas = new JTable(modeloTabla);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        tablaVentas.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        tablaVentas.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);
        tablaVentas.getColumnModel().getColumn(0).setPreferredWidth(40);
        tablaVentas.getColumnModel().getColumn(1).setPreferredWidth(130);
        tablaVentas.getColumnModel().getColumn(2).setPreferredWidth(180);
        tablaVentas.getColumnModel().getColumn(3).setPreferredWidth(150);

        JScrollPane scrollTabla = new JScrollPane(tablaVentas);
        scrollTabla.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(grisBorde),"Entradas compradas"));
        add(scrollTabla, BorderLayout.CENTER);

        cargarCombos();
        configurarRenderers();
        actualizarDetalleEspectaculo();
        cargarVentasCliente();
        configurarEventos();
    }

    private void cargarCombos()
    {
        try
        {
            cbEspectaculo.removeAllItems();
            List<Espectaculo> espectaculos = serviceEspectaculo.listarEspectaculos();
            for (Espectaculo e : espectaculos)
            {
                cbEspectaculo.addItem(e);
            }
        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al cargar espectáculos: " + e.getMessage());
        }
    }

    private void cargarUbicacionesParaEspectaculo(Espectaculo espectaculo)
    {
        cbUbicacion.removeAllItems();

        if (espectaculo == null || espectaculo.getEstadio() == null)
        {
            return;
        }

        int idEstadio = espectaculo.getEstadio().getId();
        try
        {
            List<UbicacionEntrada> ubicaciones = serviceUbicacion.listarPorEstadio(idEstadio);
            for (UbicacionEntrada u : ubicaciones)
            {
                cbUbicacion.addItem(u);
            }
        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al cargar ubicaciones del estadio: " + e.getMessage());
        }
    }

    private void configurarRenderers()
    {
        cbEspectaculo.setRenderer(new DefaultListCellRenderer()
        {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value,int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Espectaculo)
                {
                    Espectaculo e = (Espectaculo) value;
                    setText(e.getTitulo());
                }
                return this;
            }
        });
    }

    private void cargarVentasCliente()
    {
        try
        {
            modeloTabla.setRowCount(0);
            List<Venta> ventas = serviceVenta.listarVentasDeCliente(usuarioLogueado.getId());

            for (Venta v : ventas)
            {
                String fecha = (v.getFechaHora() != null)? formatoFecha.format(v.getFechaHora()): "-";
                String nombreEsp = (v.getEspectaculo() != null)? v.getEspectaculo().getTitulo(): "-";
                String nombreUbic = (v.getUbicacion() != null)? v.getUbicacion().getnombre(): "-";

                modeloTabla.addRow(new Object[]{
                        v.getId(),
                        fecha,
                        nombreEsp,
                        nombreUbic,
                        v.getTotal(),
                        v.getCantidad()
                });
            }
        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al cargar tus entradas: " + e.getMessage());
        }
    }

    private void configurarEventos()
    {
        cbEspectaculo.addActionListener(e -> actualizarDetalleEspectaculo());
        cbUbicacion.addActionListener(e -> recalcularTotal());  
        spCantidad.addChangeListener(e -> recalcularTotal());
        btnComprar.addActionListener(e -> comprarEntrada());
        btnDevolver.addActionListener(e -> devolverEntrada());
    }

    private void actualizarDetalleEspectaculo()
    {
        Espectaculo espectaculo = (Espectaculo) cbEspectaculo.getSelectedItem();
        if (espectaculo == null)
        {
            lblTituloValor.setText("-");
            lblFechaValor.setText("-");
            lblPrecioValor.setText("-");
            txtTotal.setText("");
            cbUbicacion.removeAllItems();
            mostrarImagen(null, lblPosterEspectaculo);
            mostrarImagen(null, lblFotoEstadio);
            return;
        }

        lblTituloValor.setText(espectaculo.getTitulo());

        if (espectaculo.getFechaHora() != null)
        {
            lblFechaValor.setText(espectaculo.getFechaHora().toString());
        }
        else
        {
            lblFechaValor.setText("-");
        }

        lblPrecioValor.setText(String.valueOf(espectaculo.getPrecio()));
        cargarUbicacionesParaEspectaculo(espectaculo);

        // poster del espectáculo (campo String poster en Espectaculo)
        mostrarImagen(espectaculo.getPoster(), lblPosterEspectaculo);

        // foto del estadio
        if (espectaculo.getEstadio() != null) {
            mostrarImagen(espectaculo.getEstadio().getFotoEstadio(), lblFotoEstadio);
        } else {
            mostrarImagen(null, lblFotoEstadio);
        }

        recalcularTotal();
    }

    private void recalcularTotal()
    {
        Espectaculo espectaculo = (Espectaculo) cbEspectaculo.getSelectedItem();
        UbicacionEntrada ubicacion = (UbicacionEntrada) cbUbicacion.getSelectedItem();

        if (espectaculo == null || ubicacion == null)
        {
            txtTotal.setText("");
            lblPrecioValor.setText("-");
            return;
        }

        int cantidad = (int) spCantidad.getValue();

        try
        {
            float total = serviceVenta.calcularTotalPorUbicacion(ubicacion, cantidad);
            txtTotal.setText(String.valueOf(total));
            lblPrecioValor.setText(String.valueOf(ubicacion.getPrecio())); 
        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al calcular el total: " + e.getMessage());
        }
    }


    private void comprarEntrada()
    {
        Espectaculo espectaculo = (Espectaculo) cbEspectaculo.getSelectedItem();
        UbicacionEntrada ubicacion = (UbicacionEntrada)cbUbicacion.getSelectedItem();

        if(espectaculo == null || ubicacion == null)
        {
            JOptionPane.showMessageDialog(this,"Debe seleccionar un espectáculo y ubicación.");
            return;
        }
        int cantidad = (int) spCantidad.getValue();

        try
        {
            if(!serviceVenta.hayCapacidadEnEstadio(espectaculo, cantidad))
            {
                JOptionPane.showMessageDialog(this,"No hay capacidad suficiente en el estadio. " +espectaculo.getEstadio().getCapacidad(),"Estadio lleno.",JOptionPane.WARNING_MESSAGE);
                return;
            }
            if(!serviceVenta.hayCapacidadEnUbicacion(espectaculo, ubicacion,cantidad))
            {
                JOptionPane.showMessageDialog(this,"No hay capacidad suficiente en la ubicación seleccionada. " +ubicacion.getCapacidad(),"Ubicación llena.",JOptionPane.WARNING_MESSAGE);
                return;
            }
            serviceVenta.registrarVentaCliente(usuarioLogueado.getId(),espectaculo.getId(),ubicacion.getId(),cantidad);
            JOptionPane.showMessageDialog(this,"Entrada comprada correctamente.","Éxito",JOptionPane.INFORMATION_MESSAGE);
            cargarVentasCliente();
        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al comprar: " + e.getMessage());
        }

    }

    private void devolverEntrada()
    {
        int fila = tablaVentas.getSelectedRow();
        if (fila == -1)
        {
            JOptionPane.showMessageDialog(this,"Seleccione una entrada en la tabla para devolver.","Sin selección",JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idVenta = (int) modeloTabla.getValueAt(fila, 0);

        int opcion = JOptionPane.showConfirmDialog(this,"¿Seguro que desea devolver esta entrada?","Confirmar devolución",JOptionPane.YES_NO_OPTION);
        if (opcion != JOptionPane.YES_OPTION)
        {
            return;
        }

        try
        {
            serviceVenta.devolverVenta(idVenta);
            JOptionPane.showMessageDialog(this,"Entrada devuelta.", "Éxito",JOptionPane.INFORMATION_MESSAGE);
            cargarVentasCliente();
        }
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this,"Error al devolver entrada: " + e.getMessage());
        }
    }


    private void mostrarImagen(String ruta, JLabel destino) 
    {
        if (ruta == null || ruta.isEmpty()) 
        {
            destino.setIcon(null);
            if (destino == lblPosterEspectaculo) 
            {
                destino.setText("Sin poster");
            } 
            else if (destino == lblFotoEstadio) 
            {
                destino.setText("Sin foto estadio");
            } 
            else 
            {
                destino.setText("Sin foto");
            }
            return;
        }
        int w = destino.getWidth();
        int h = destino.getHeight();

        if (w <= 0 || h <= 0) 
        {
            Dimension pref = destino.getPreferredSize();
            w = (pref != null && pref.width  > 0) ? pref.width  : 220;
            h = (pref != null && pref.height > 0) ? pref.height : 160;
        }

        ImageIcon icon = new ImageIcon(ruta);
        Image img = icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH);

        destino.setText("");
        destino.setIcon(new ImageIcon(img));
    }
}

