package gui;

import entidades.Usuario;
import service.ServiceException;
import service.ServiceUsuario;

import javax.swing.*;
import java.awt.*;

public class VentanaRegistroCliente extends JFrame {

    private JTextField txtNombre;
    private JTextField txtMail;
    private JPasswordField txtClave;
    private JPasswordField txtClaveRepetida;
    private JButton btnRegistrarse;

    private ServiceUsuario serviceUsuario;

    public VentanaRegistroCliente() {

        serviceUsuario = new ServiceUsuario();

        setTitle("Registro de cliente");
        setSize(420, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color rosaSuave = new Color(244, 205, 210);
        Color azulTitulo = new Color(5, 51, 66);

        JLabel lblTitulo = new JLabel("Crear cuenta de cliente");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.setBackground(Color.WHITE);
        panelCentro.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nombre
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtNombre = new JTextField();
        panelCentro.add(txtNombre, gbc);

        // Mail
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Mail:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtMail = new JTextField();
        panelCentro.add(txtMail, gbc);

        // Clave
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Clave:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtClave = new JPasswordField();
        panelCentro.add(txtClave, gbc);

        // Repetir clave
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Repetir clave:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtClaveRepetida = new JPasswordField();
        panelCentro.add(txtClaveRepetida, gbc);

        add(panelCentro, BorderLayout.CENTER);

        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(rosaSuave);
        panelBoton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btnRegistrarse = new JButton("Registrarse");
        btnRegistrarse.setBackground(azulTitulo);
        btnRegistrarse.setForeground(Color.WHITE);
        btnRegistrarse.setFocusPainted(false);

        panelBoton.add(btnRegistrarse);
        add(panelBoton, BorderLayout.SOUTH);

        btnRegistrarse.addActionListener(e -> registrarCliente());
    }

    private void registrarCliente()
    {
        String nombre = txtNombre.getText().trim();
        String mail = txtMail.getText().trim();
        String clave = new String(txtClave.getPassword());
        String clave2 = new String(txtClaveRepetida.getPassword());

        if (nombre.isEmpty() || mail.isEmpty() || clave.isEmpty() || clave2.isEmpty()) 
        {
            JOptionPane.showMessageDialog(this, "Completá todos los campos.");
            return;
        }

        if (!clave.equals(clave2)) 
        {
            JOptionPane.showMessageDialog(this, "Las claves no coinciden.");
            return;
        }

        try 
        {
            Usuario u = serviceUsuario.registrarCliente(nombre, mail, clave);
            JOptionPane.showMessageDialog(this, "Cliente registrado correctamente. Ya podés iniciar sesión.");
            dispose();
        } 
        catch (ServiceException e)
        {
            JOptionPane.showMessageDialog(this,"Error al registrar cliente: " + e.getMessage());
        }
    }
}
