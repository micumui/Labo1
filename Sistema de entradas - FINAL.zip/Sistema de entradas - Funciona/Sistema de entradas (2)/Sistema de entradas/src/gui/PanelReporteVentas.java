package gui;

import dao.DaoException;
import service.ServiceVenta;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PanelReporteVentas extends JPanel {

    private JTextField txtDesde;
    private JTextField txtHasta;
    private JButton btnFiltrar;

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    private ServiceVenta serviceVenta;
    private SimpleDateFormat formatoEntrada = new SimpleDateFormat("dd/MM/yyyy");
    private SimpleDateFormat formatoFechaHora = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public PanelReporteVentas() {

        serviceVenta = new ServiceVenta();

        Color rosaSuave = new Color(244, 205, 210);
        Color grisBorde = new Color(230, 230, 230);
        Color azulTitulo = new Color(5, 51, 66);

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblTitulo = new JLabel("Reporte de ventas por espectáculo");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);


        JPanel panelFiltros = new JPanel(new GridBagLayout());
        panelFiltros.setBackground(Color.WHITE);
        panelFiltros.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(grisBorde),"Filtro por fechas"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        int fila = 0;

        txtDesde = new JTextField(10);
        txtHasta = new JTextField(10);

        gbc.gridx = 0; gbc.gridy = fila;
        panelFiltros.add(new JLabel("Desde (dd/MM/yyyy):"), gbc);
        gbc.gridx = 1;
        panelFiltros.add(txtDesde, gbc);
        fila++;

        gbc.gridx = 0; gbc.gridy = fila;
        panelFiltros.add(new JLabel("Hasta (dd/MM/yyyy):"), gbc);
        gbc.gridx = 1;
        panelFiltros.add(txtHasta, gbc);
        fila++;

        btnFiltrar = new JButton("Generar reporte");
        btnFiltrar.setBackground(rosaSuave);
        gbc.gridx = 0; gbc.gridy = fila; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panelFiltros.add(btnFiltrar, gbc);

        add(panelFiltros, BorderLayout.WEST);


        modeloTabla = new DefaultTableModel(new Object[]{"Espectáculo", "Entradas vendidas", "Total recaudado"}, 0) 
        {
            @Override
            public boolean isCellEditable(int row, int column) 
            { 
                return false; 
            }
        };

        tabla = new JTable(modeloTabla);

        DefaultTableCellRenderer right = new DefaultTableCellRenderer();
        right.setHorizontalAlignment(SwingConstants.RIGHT);
        tabla.getColumnModel().getColumn(1).setCellRenderer(right);
        tabla.getColumnModel().getColumn(2).setCellRenderer(right);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(grisBorde),"Resultados"));
        add(scroll, BorderLayout.CENTER);

        btnFiltrar.addActionListener(e -> generarReporte());
    }

    private void generarReporte() 
    {

        Date fechaDesde;
        Date fechaHasta;

        try 
        {
            String textoDesde = txtDesde.getText().trim();
            String textoHasta = txtHasta.getText().trim();

            if (textoDesde.isEmpty() || textoHasta.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this,"Debe completar ambas fechas.","Datos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            fechaDesde = formatoEntrada.parse(textoDesde);
            fechaHasta = formatoEntrada.parse(textoHasta);

        } 
        catch (ParseException ex) 
        {
            JOptionPane.showMessageDialog(this,"Formato de fecha inválido. Use dd/MM/yyyy.","Error en fechas", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try 
        {
            modeloTabla.setRowCount(0);

          
            List<Object[]> resumenes =serviceVenta.reportePorEspectaculo(fechaDesde, fechaHasta);

            for (Object[] fila : resumenes) 
            {
                modeloTabla.addRow(fila);
            }

            if (resumenes.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this,"No hay ventas en el rango seleccionado.");
            }

        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al generar reporte: " + e.getMessage());
        }
}

}
