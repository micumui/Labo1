package gui;

import javax.swing.*;
import java.awt.*;

public class VentanaSeleccionRegistro extends JFrame {

    public VentanaSeleccionRegistro() 
    {

        setTitle("Crear cuenta");
        setSize(350, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        Color rosaSuave = new Color(244, 205, 210);
        Color azulTitulo = new Color(5, 51, 66);

        JLabel lblTitulo = new JLabel("Seleccioná el tipo de cuenta");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel(new GridLayout(2, 1, 10, 10));
        panelCentro.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        panelCentro.setBackground(Color.WHITE);

        JButton btnAdmins = new JButton("Crear cuenta administradores");
        JButton btnCliente = new JButton("Crear cuenta cliente");

        panelCentro.add(btnAdmins);
        panelCentro.add(btnCliente);

        add(panelCentro, BorderLayout.CENTER);

        JPanel panelSur = new JPanel();
        panelSur.setBackground(rosaSuave);
        add(panelSur, BorderLayout.SOUTH);

        btnAdmins.addActionListener(e -> {
            new VentanaRegistroAdminVend().setVisible(true);
            dispose();
        });

        btnCliente.addActionListener(e -> {
            new VentanaRegistroCliente().setVisible(true);
            dispose();
        });
    }
}
