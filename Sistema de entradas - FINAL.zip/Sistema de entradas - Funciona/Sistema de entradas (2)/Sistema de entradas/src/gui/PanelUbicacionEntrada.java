package gui;

import dao.DaoEstadio;
import dao.DaoException;
import dao.DaoUbicacionEntrada;
import entidades.Estadio;
import entidades.UbicacionEntrada;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelUbicacionEntrada extends JPanel {

    private JComboBox<Estadio> cmbEstadio;
    private JTextField txtnombre;
    private JTextField txtCapacidad;
    private JTextField txtPrecio;
    private JButton btnGuardar;
    private JButton btnEliminar;
    private JTable tablaUbicaciones;
    private DefaultTableModel modeloTabla;

    private DaoUbicacionEntrada daoUbicacion;
    private DaoEstadio daoEstadio;
    private Long ubicacionSeleccionadaId = null;

    public PanelUbicacionEntrada() {

        daoUbicacion = new DaoUbicacionEntrada();
        daoEstadio   = new DaoEstadio();

        Color rosaSuave  = new Color(244, 205, 210);
        Color grisBorde  = new Color(230, 230, 230);
        Color azulTitulo = new Color(5, 51, 66);

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Administración de ubicaciones");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        add(panelTitulo, BorderLayout.NORTH);

        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BoxLayout(panelFormulario, BoxLayout.X_AXIS));
        panelFormulario.setBackground(rosaSuave);
        panelFormulario.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel panelAlta = new JPanel(new GridBagLayout());
        panelAlta.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        JLabel lblNuevo = new JLabel("Nueva ubicación");
        lblNuevo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblNuevo.setForeground(azulTitulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        panelAlta.add(lblNuevo, gbc);


        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Estadio:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        cmbEstadio = new JComboBox<>();
        cmbEstadio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbEstadio.setPreferredSize(new Dimension(250, 28));
        panelAlta.add(cmbEstadio, gbc);

  
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        txtnombre = new JTextField();
        txtnombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtnombre.setPreferredSize(new Dimension(250, 28));
        txtnombre.setBorder(BorderFactory.createLineBorder(grisBorde, 1));
        panelAlta.add(txtnombre, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Capacidad:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        txtCapacidad = new JTextField();
        txtCapacidad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCapacidad.setPreferredSize(new Dimension(150, 28));
        txtCapacidad.setBorder(BorderFactory.createLineBorder(grisBorde, 1));
        panelAlta.add(txtCapacidad, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Precio:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        txtPrecio = new JTextField();
        txtPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPrecio.setPreferredSize(new Dimension(150, 28));
        txtPrecio.setBorder(BorderFactory.createLineBorder(grisBorde, 1));
        panelAlta.add(txtPrecio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(15, 10, 5, 10);
        btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(new Color(5, 51, 66));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        panelAlta.add(btnGuardar, gbc);

        JPanel panelEliminar = new JPanel();
        panelEliminar.setOpaque(false);
        panelEliminar.setLayout(new BoxLayout(panelEliminar, BoxLayout.Y_AXIS));
        panelEliminar.setBorder(new EmptyBorder(10, 30, 10, 10));

        JLabel lblEliminar = new JLabel("Eliminar ubicación");
        lblEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblEliminar.setForeground(azulTitulo);
        lblEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel paso1 = new JLabel("1. Seleccioná una ubicación de la tabla.");
        paso1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        paso1.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel paso2 = new JLabel("2. Hacé clic en Eliminar.");
        paso2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        paso2.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnEliminar.setBackground(new Color(204, 0, 0));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder(5, 20, 5, 20));
        btnEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelEliminar.add(lblEliminar);
        panelEliminar.add(Box.createVerticalStrut(10));
        panelEliminar.add(paso1);
        panelEliminar.add(paso2);
        panelEliminar.add(Box.createVerticalStrut(20));
        panelEliminar.add(btnEliminar);
        panelEliminar.add(Box.createVerticalGlue());

        panelFormulario.add(panelAlta);
        panelFormulario.add(Box.createHorizontalStrut(30));
        panelFormulario.add(panelEliminar);

        modeloTabla = crearModeloTabla();
        tablaUbicaciones = new JTable(modeloTabla);
        tablaUbicaciones.setFillsViewportHeight(true);
        tablaUbicaciones.setRowHeight(22);
        tablaUbicaciones.getTableHeader().setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(tablaUbicaciones);
        scroll.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(grisBorde, 1),new EmptyBorder(5, 5, 5, 5)));
        scroll.getViewport().setBackground(Color.WHITE);

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setOpaque(false);
        JLabel lblTabla = new JLabel("Ubicaciones");
        lblTabla.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTabla.setForeground(azulTitulo);
        lblTabla.setBorder(new EmptyBorder(5, 0, 5, 0));
        panelTabla.add(lblTabla, BorderLayout.NORTH);
        panelTabla.add(scroll, BorderLayout.CENTER);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelFormulario, panelTabla);
        split.setResizeWeight(0.45);
        split.setDividerSize(6);
        split.setBorder(null);

        add(split, BorderLayout.CENTER);

        tablaUbicaciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaUbicaciones.getSelectionModel().addListSelectionListener(e -> {if (!e.getValueIsAdjusting()) {modificarUbicacionDesdeTabla();}});

        btnGuardar.addActionListener(e -> guardarUbicacion());
        btnEliminar.addActionListener(e -> eliminarUbicacion());

        cargarEstadiosEnCombo();
        cargarTabla();
    }

    private void cargarEstadiosEnCombo() 
    {
        try 
        {
            cmbEstadio.removeAllItems();
            List<Estadio> estadios = daoEstadio.consultarTodos();
            for (Estadio e : estadios) 
            {
                cmbEstadio.addItem(e);
            }
        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar estadios: " + e.getMessage());
        }
    }

    private DefaultTableModel crearModeloTabla() 
    {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("id");
        modelo.addColumn("Estadio");
        modelo.addColumn("Nombre");
        modelo.addColumn("Capacidad");
        modelo.addColumn("Precio");
        return modelo;
    }

    private void cargarTabla() 
    {
        try 
        {
            List<UbicacionEntrada> lista = daoUbicacion.consultarTodos();
            modeloTabla.setRowCount(0);

            for (UbicacionEntrada u : lista)
            {
                String nombreEstadio = (u.getEstadio() != null) ? u.getEstadio().getNombre() : "";
                modeloTabla.addRow(new Object[]{
                        u.getId(),
                        nombreEstadio,
                        u.getnombre(),
                        u.getCapacidad(),
                        u.getPrecio()
                });
            }
            modeloTabla.fireTableDataChanged();
        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar ubicaciones: " + e.getMessage());
        }
    }

    private void guardarUbicacion() 
    {
        try
        {

            String nombre = txtnombre.getText();
            String capacidadStr = txtCapacidad.getText();
            String precioStr = txtPrecio.getText();
            Estadio estadioSel = (Estadio) cmbEstadio.getSelectedItem();

            if (nombre == null || nombre.trim().isEmpty()|| capacidadStr == null || capacidadStr.trim().isEmpty()|| precioStr == null || precioStr.trim().isEmpty()|| estadioSel == null) 
            {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
                return;
            }

            int   capacidad = Integer.parseInt(capacidadStr);
            float precio    = Float.parseFloat(precioStr);

            UbicacionEntrada u = new UbicacionEntrada();
            u.setnombre(nombre);
            u.setCapacidad(capacidad);
            u.setPrecio(precio);
            u.setEstadio(estadioSel);

            if (ubicacionSeleccionadaId == null) 
            {
                daoUbicacion.insertar(u);
                JOptionPane.showMessageDialog(this, "Ubicación guardada correctamente.");
            } 
            else 
            {
                u.setId(ubicacionSeleccionadaId.intValue());
                daoUbicacion.modificar(u);
                JOptionPane.showMessageDialog(this, "Ubicación modificada correctamente.");
            }

            limpiarCampos();
            cargarTabla();

        }
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage());
        }
    }

    private void limpiarCampos() 
    {
        txtnombre.setText("");
        txtCapacidad.setText("");
        txtPrecio.setText("");
        ubicacionSeleccionadaId = null;
        btnGuardar.setText("Guardar");
        tablaUbicaciones.clearSelection();
    }

    private void modificarUbicacionDesdeTabla() 
    {
        int fila = tablaUbicaciones.getSelectedRow();
        if (fila == -1) 
        {
            return;
        }

        Object valorId = tablaUbicaciones.getValueAt(fila, 0);
        if (valorId instanceof Number) 
        {
            ubicacionSeleccionadaId = ((Number) valorId).longValue();
        } 
        else 
        {
            ubicacionSeleccionadaId = Long.parseLong(valorId.toString());
        }

        String nombre = String.valueOf(tablaUbicaciones.getValueAt(fila, 2));
        String capacidadStr = String.valueOf(tablaUbicaciones.getValueAt(fila, 3));
        String precioStr = String.valueOf(tablaUbicaciones.getValueAt(fila, 4));
        String nombreEstadio = String.valueOf(tablaUbicaciones.getValueAt(fila, 1));

        txtnombre.setText(nombre);
        txtCapacidad.setText(capacidadStr);
        txtPrecio.setText(precioStr);
        
        for (int i = 0; i < cmbEstadio.getItemCount(); i++)
        {
            Estadio est = cmbEstadio.getItemAt(i);
            if (est != null && est.getNombre().equals(nombreEstadio)) 
            {
                cmbEstadio.setSelectedIndex(i);
                i = cmbEstadio.getItemCount();
            }
        }
        btnGuardar.setText("Modificar");
    }

    private void eliminarUbicacion() 
    {
        int filaSeleccionada = tablaUbicaciones.getSelectedRow();
        if (filaSeleccionada == -1)
        {
            JOptionPane.showMessageDialog(this, "Seleccioná una ubicación para eliminar.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,"¿Desea eliminar esta ubicación?","Confirmar",JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) 
        {
            try 
            {
                int id = (int) tablaUbicaciones.getValueAt(filaSeleccionada, 0);
                daoUbicacion.eliminar(id);
                JOptionPane.showMessageDialog(this, "Ubicación eliminada correctamente.");
                limpiarCampos();
                cargarTabla();
            }
            catch (DaoException e) 
            {
                JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
            }
        }
    }
}
