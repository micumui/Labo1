package gui;

import dao.DaoException;
import dao.DaoUbicacionEntrada;
import entidades.UbicacionEntrada;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelListadoUbicaciones extends JPanel {

    private JTable tablaUbicaciones;
    private DefaultTableModel modeloTabla;
    private DaoUbicacionEntrada daoUbicacion;

    private JTextField txtRutaFotoUbicacion;
    private JButton btnSeleccionarFotoUbicacion;
    private JLabel lblFotoUbicacionPreview;

    public PanelListadoUbicaciones() {

        daoUbicacion = new DaoUbicacionEntrada();

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Listado de ubicaciones");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        add(lblTitulo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(
                new Object[]{"ID", "Estadio", "Nombre", "Capacidad", "Precio"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaUbicaciones = new JTable(modeloTabla);
        tablaUbicaciones.setRowHeight(22);
        tablaUbicaciones.getTableHeader().setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(tablaUbicaciones);

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setOpaque(false);
        panelTabla.add(scroll, BorderLayout.CENTER);

    
        JPanel panelFoto = new JPanel(new GridBagLayout());
        panelFoto.setOpaque(false);
        panelFoto.setBorder(new EmptyBorder(0, 15, 0, 0));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        JLabel lblFotoTitulo = new JLabel("Foto de la ubicación");
        lblFotoTitulo.setFont(new Font("Segoe UI", Font.BOLD, 14));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelFoto.add(lblFotoTitulo, gbc);
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panelFoto.add(new JLabel("Ruta:"), gbc);
        txtRutaFotoUbicacion = new JTextField(20);
        txtRutaFotoUbicacion.setEditable(false);
        gbc.gridx = 1;
        panelFoto.add(txtRutaFotoUbicacion, gbc);

    
        btnSeleccionarFotoUbicacion = new JButton("Seleccionar foto");
        gbc.gridy = 2;
        gbc.gridx = 1;
        panelFoto.add(btnSeleccionarFotoUbicacion, gbc);

        
        lblFotoUbicacionPreview = new JLabel("Sin foto");
        lblFotoUbicacionPreview.setPreferredSize(new Dimension(220, 160));
        lblFotoUbicacionPreview.setHorizontalAlignment(SwingConstants.CENTER);
        lblFotoUbicacionPreview.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panelFoto.add(lblFotoUbicacionPreview, gbc);

      
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelTabla, panelFoto);
        split.setResizeWeight(0.7);
        split.setDividerSize(6);
        split.setBorder(null);

        add(split, BorderLayout.CENTER);

       
        tablaUbicaciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaUbicaciones.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) 
            {
                cargarFotoUbicacionSeleccionada();
            }
        });

        btnSeleccionarFotoUbicacion.addActionListener(e -> seleccionarFotoUbicacion());

        cargarTabla();
    }

    private void cargarTabla() 
    {
        modeloTabla.setRowCount(0);
        try 
        {
            List<UbicacionEntrada> lista = daoUbicacion.consultarTodos();
            for (UbicacionEntrada u : lista) 
            {
                String nombreEstadio = (u.getEstadio() != null) ? u.getEstadio().getNombre() : "";
                modeloTabla.addRow(new Object[]{
                        u.getId(),
                        nombreEstadio,
                        u.getnombre(),     
                        u.getCapacidad(),
                        u.getPrecio()
                });
            }
        }
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al cargar ubicaciones: " + e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarFotoUbicacionSeleccionada() 
    {
        int fila = tablaUbicaciones.getSelectedRow();
        if (fila == -1) 
        {
            txtRutaFotoUbicacion.setText("");
            mostrarFotoEnLabel(null, lblFotoUbicacionPreview);
            return;
        }

        int id = (int) modeloTabla.getValueAt(fila, 0);
        try 
        {
            UbicacionEntrada u = daoUbicacion.consultar(id);
            txtRutaFotoUbicacion.setText(u.getFotoUbicacion());
            mostrarFotoEnLabel(u.getFotoUbicacion(), lblFotoUbicacionPreview);
        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al cargar foto de ubicación: " + e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
    }


    private void seleccionarFotoUbicacion() 
    {
        int fila = tablaUbicaciones.getSelectedRow();
        if (fila == -1) 
        {
            JOptionPane.showMessageDialog(this,"Seleccioná una ubicación en la tabla primero.","Sin selección",JOptionPane.WARNING_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int opcion = chooser.showOpenDialog(this);
        if (opcion == JFileChooser.APPROVE_OPTION) 
        {
            String ruta = chooser.getSelectedFile().getAbsolutePath();
            txtRutaFotoUbicacion.setText(ruta);
            mostrarFotoEnLabel(ruta, lblFotoUbicacionPreview);

            int id = (int) modeloTabla.getValueAt(fila, 0);
            try 
            {
                UbicacionEntrada u = daoUbicacion.consultar(id);
                u.setFotoUbicacion(ruta);
                daoUbicacion.modificar(u);
            } 
            catch (DaoException e) 
            {
                JOptionPane.showMessageDialog(this,"Error al guardar foto de ubicación: " + e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void mostrarFotoEnLabel(String ruta, JLabel label) 
    {
        if (ruta == null || ruta.isEmpty())
        {
            label.setIcon(null);
            label.setText("Sin foto");
            return;
        }

        ImageIcon icon = new ImageIcon(ruta);
        Image img = icon.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_SMOOTH);
        label.setText("");
        label.setIcon(new ImageIcon(img));
    }
}
