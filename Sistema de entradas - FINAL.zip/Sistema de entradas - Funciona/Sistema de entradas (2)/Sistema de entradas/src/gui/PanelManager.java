package gui;

import entidades.Usuario;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class PanelManager extends JPanel {

    private CardLayout cardLayout;
    private Map<String, JPanel> paneles;

    public PanelManager(Usuario usuarioLogueado)
    {
        cardLayout = new CardLayout();
        setLayout(cardLayout);
        paneles = new HashMap<>();

        PanelListadoEstadios panelEstadiosVer = new PanelListadoEstadios();
        agregarPanel(panelEstadiosVer, "EstadiosVer");

        PanelEstadios panelEstadiosAdmin = new PanelEstadios();
        agregarPanel(panelEstadiosAdmin, "EstadiosAdmin");

        PanelListadoUbicaciones panelUbicVer = new PanelListadoUbicaciones();
        agregarPanel(panelUbicVer, "UbicacionesVer");

        PanelUbicacionEntrada panelUbicAdmin = new PanelUbicacionEntrada();
        agregarPanel(panelUbicAdmin, "UbicacionesAdmin");

        PanelListadoEspectaculos panelEspVer = new PanelListadoEspectaculos();
        agregarPanel(panelEspVer, "EspectaculosVer");

        PanelEspectaculo panelEspAdmin = new PanelEspectaculo();
        agregarPanel(panelEspAdmin, "EspectaculosAdmin");

        PanelVentas panelVentas = new PanelVentas(usuarioLogueado);
        agregarPanel(panelVentas, "Ventas");

        PanelEntradasCliente panelEntradasCliente = new PanelEntradasCliente(usuarioLogueado);
        agregarPanel(panelEntradasCliente, "EntradasCliente");

        PanelReporteVentas panelReporteVentas = new PanelReporteVentas();
        agregarPanel(panelReporteVentas, "ReporteVentas");


        mostrarPanel("EstadiosVer");
    }

    public void agregarPanel(JPanel panel, String nombre) {
        paneles.put(nombre, panel);
        add(panel, nombre);
    }

    public void mostrarPanel(String nombre) {
        cardLayout.show(this, nombre);
    }
}
