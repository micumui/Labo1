package entidades;

public class UbicacionEntrada {
    
    int id;
    int capacidad;
    float precio;
    String nombre;
    String fotoUbicacion;
    Estadio estadio;

    //Constructores
    public UbicacionEntrada() 
    {
    }

    public UbicacionEntrada(int id, int capacidad, float precio, String nombre) 
    {
        this.id = id;
        this.capacidad = capacidad;
        this.precio = precio;
        this.nombre = nombre;
    }

    //Getters
    public int getId() 
    {
        return id;
    }

    public int getCapacidad() 
    {
        return capacidad;
    }
    public float getPrecio() 
    {
        return precio;
    }
    public String getnombre() 
    {
        return nombre;
    }
    public String getFotoUbicacion()
    {
        return fotoUbicacion;
    }
    public Estadio getEstadio()
    {
        return estadio;
    }

    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setCapacidad(int capacidad) 
    {
        this.capacidad = capacidad;
    }
    public void setPrecio(float precio) 
    {
        this.precio = precio;
    }
    public void setnombre(String nombre) 
    {
        this.nombre = nombre;
    }
    public void setFotoUbicacion(String fotoUbicacion)
    {
        this.fotoUbicacion = fotoUbicacion;
    }
    public void setEstadio(Estadio estadio)
    {
        this.estadio= estadio;
    }

    @Override
    public String toString() {
        return "Ubicación: " + nombre;
    }

    

}
