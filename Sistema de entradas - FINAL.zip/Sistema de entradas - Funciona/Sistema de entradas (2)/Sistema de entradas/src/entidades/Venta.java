package entidades;

import java.sql.Timestamp;

public class Venta {

    int id;
    Timestamp fechaHora;
    Usuario cliente;
    Usuario vendedor;
    Espectaculo espectaculo;
    UbicacionEntrada ubicacion;
    float total;
    int cantidad;

    public Venta() 
    {
    }

    public Venta(int id, Timestamp fechaHora, Usuario cliente, Usuario vendedor,Espectaculo espectaculo, UbicacionEntrada ubicacion, float total,int cantidad) 
    {
        this.id = id;
        this.fechaHora = fechaHora;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.espectaculo = espectaculo;
        this.ubicacion = ubicacion;
        this.total = total;
        this.cantidad = cantidad;
    }

    //Getters
    public int getId() {
        return id;
    }

    public Timestamp getFechaHora() {
        return fechaHora;
    }

    public Usuario getCliente() {
        return cliente;
    }

    public Usuario getVendedor() {
        return vendedor;
    }

    public Espectaculo getEspectaculo() {
        return espectaculo;
    }

    public UbicacionEntrada getUbicacion() {
        return ubicacion;
    }

    public float getTotal() {
        return total;
    }

    public int getCantidad()
    {
        return cantidad;
    }

    //Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setFechaHora(Timestamp fechaHora) {
        this.fechaHora = fechaHora;
    }

    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

    public void setVendedor(Usuario vendedor) {
        this.vendedor = vendedor;
    }

    public void setEspectaculo(Espectaculo espectaculo) {
        this.espectaculo = espectaculo;
    }

    public void setUbicacion(UbicacionEntrada ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public void setCantidad(int cantidad)
    {
        this.cantidad = cantidad;
    } 
}
