package entidades;
import java.util.List;

public class Estadio {

    String direccion;
    String nombre;
    int capacidad;
    int id;
    String fotoEstadio;
    List<UbicacionEntrada> ubicaciones;
    
    //Constructores
    public Estadio() 
    {
    }

    public Estadio(String direccion, String nombre, int id, int capacidad) 
    {
        this.direccion = direccion;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.id = id;
    }

    //Getters
    public String getDireccion() 
    {
        return direccion;
    }

    public String getNombre() 
    {
        return nombre;
    }

    public int getId() 
    {
        return id;
    }

    public int getCapacidad()
    {
        return capacidad;
    }
    public String getFotoEstadio()
    {
        return fotoEstadio;
    }
    public List<UbicacionEntrada> getUbicaciones()
    {
        return ubicaciones;
    }

    //Settters
    public void setDireccion(String direccion) 
    {
        this.direccion = direccion;
    }

    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }

    public void setId(int id) 
    {
        this.id = id;
    }
    
    public void setCapacidad(int capacidad)
    {
        this.capacidad = capacidad;
    }
    public void setFotoEstadio(String fotoEstadio)
    {
        this.fotoEstadio = fotoEstadio;
    }
    public void setUbicaciones(List<UbicacionEntrada> ubicaciones)
    {
        this.ubicaciones = ubicaciones;
    }

    @Override
    public String toString() {
        return "Estadio " + nombre;
    }
    

    @Override
    public boolean equals(Object o) 
    {
        if (this == o) return true;
        if (!(o instanceof Estadio)) return false;
        Estadio est = (Estadio) o;
        return this.id == est.id;
    }

    @Override
    public int hashCode() 
    {
        return Integer.hashCode(id);
    }

        

    

    
}
