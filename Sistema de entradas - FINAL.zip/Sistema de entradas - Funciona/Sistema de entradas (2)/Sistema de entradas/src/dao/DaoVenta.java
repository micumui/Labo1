package dao;

import entidades.Venta;
import entidades.Usuario;
import entidades.Espectaculo;
import entidades.UbicacionEntrada;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoVenta implements IDAO<Venta> {

    private String DB_JDBC_DRIVER = "org.h2.Driver";
    private String DB_URL = "jdbc:h2:~/test";
    private String DB_USER = "sa";
    private String DB_PASSWORD = "";

    private DaoUsuario daoUsuario = new DaoUsuario();
    private DaoEspectaculo daoEspectaculo = new DaoEspectaculo();
    private DaoUbicacionEntrada daoUbicacionEntrada = new DaoUbicacionEntrada();

    //Inserrtar
    @Override
    public void insertar(Venta elemento) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("INSERT INTO VENTA (FECHA_HORA, CLIENTE_ID, VENDEDOR_ID, ESPECTACULO_ID, UBICACION_ID, CANTIDAD, TOTAL) VALUES (?,?,?,?,?,?,?)");

            preparedStatement.setTimestamp(1, elemento.getFechaHora());
            preparedStatement.setInt(2, elemento.getCliente().getId());
            preparedStatement.setInt(3, elemento.getVendedor().getId());
            preparedStatement.setInt(4, elemento.getEspectaculo().getId());
            preparedStatement.setInt(5, elemento.getUbicacion().getId());
            preparedStatement.setInt(6, elemento.getCantidad());
            preparedStatement.setFloat(7, elemento.getTotal());

            preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Fallo la base de datos. " + e.getMessage());
        }
    }

    // Modificar
    @Override
    public void modificar(Venta elemento) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("UPDATE VENTA SET FECHA_HORA = ?,CLIENTE_ID = ?,VENDEDOR_ID = ?,ESPECTACULO_ID = ?,UBICACION_ID = ?,CANTIDAD = ?,TOTAL = ? WHERE ID = ?");

            preparedStatement.setTimestamp(1, elemento.getFechaHora());
            preparedStatement.setInt(2, elemento.getCliente().getId());
            preparedStatement.setInt(3, elemento.getVendedor().getId());
            preparedStatement.setInt(4, elemento.getEspectaculo().getId());
            preparedStatement.setInt(5, elemento.getUbicacion().getId());
            preparedStatement.setInt(6, elemento.getCantidad());
            preparedStatement.setFloat(7, elemento.getTotal());
            preparedStatement.setInt(8, elemento.getId());

            preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e) {
            throw new DaoException("Error al modificar venta. " + e.getMessage());
        }
    }

    //Eliminar
    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("DELETE FROM VENTA WHERE ID = ?");
            preparedStatement.setInt(1, id);

            preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al eliminar venta. " + e.getMessage());
        }
    }

    // Consultar 1
    @Override
    public Venta consultar(int id) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Venta venta = new Venta();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, FECHA_HORA, CLIENTE_ID, VENDEDOR_ID,ESPECTACULO_ID, UBICACION_ID, CANTIDAD, TOTAL FROM VENTA WHERE ID = ?");
            preparedStatement.setInt(1, id);

            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next())
            {
                venta.setId(rs.getInt("ID"));
                venta.setFechaHora(rs.getTimestamp("FECHA_HORA"));

                int idCliente = rs.getInt("CLIENTE_ID");
                int idVendedor = rs.getInt("VENDEDOR_ID");
                int idEspectaculo = rs.getInt("ESPECTACULO_ID");
                int idUbicacion = rs.getInt("UBICACION_ID");

                Usuario cliente = daoUsuario.consultar(idCliente);
                Usuario vendedor = daoUsuario.consultar(idVendedor);
                Espectaculo espectaculo = daoEspectaculo.consultar(idEspectaculo);
                UbicacionEntrada ubicacion = daoUbicacionEntrada.consultar(idUbicacion);

                venta.setCliente(cliente);
                venta.setVendedor(vendedor);
                venta.setEspectaculo(espectaculo);
                venta.setUbicacion(ubicacion);
                venta.setCantidad(rs.getInt("CANTIDAD"));
                venta.setTotal(rs.getFloat("TOTAL"));
            }
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error en la consulta de venta. esteeee " + e.getMessage());
        }

        return venta;
    }

    //Consultar todo
    @Override
    public List<Venta> consultarTodos() throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        List<Venta> ventas = new ArrayList<>();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, FECHA_HORA, CLIENTE_ID, VENDEDOR_ID,ESPECTACULO_ID, UBICACION_ID, CANTIDAD, TOTAL FROM VENTA");

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) 
            {
                Venta venta = new Venta();
                venta.setId(rs.getInt("ID"));
                venta.setFechaHora(rs.getTimestamp("FECHA_HORA"));

                int idCliente = rs.getInt("CLIENTE_ID");
                int idVendedor = rs.getInt("VENDEDOR_ID");
                int idEspectaculo = rs.getInt("ESPECTACULO_ID");
                int idUbicacion = rs.getInt("UBICACION_ID");

                Usuario cliente = daoUsuario.consultar(idCliente);
                Usuario vendedor = daoUsuario.consultar(idVendedor);
                Espectaculo espectaculo = daoEspectaculo.consultar(idEspectaculo);
                UbicacionEntrada ubicacion = daoUbicacionEntrada.consultar(idUbicacion);

                venta.setCliente(cliente);
                venta.setVendedor(vendedor);
                venta.setEspectaculo(espectaculo);
                venta.setUbicacion(ubicacion);
                venta.setCantidad(rs.getInt("CANTIDAD"));
                venta.setTotal(rs.getFloat("TOTAL"));

                ventas.add(venta);
            }
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error en la consulta de ventas. aca " + e.getMessage());
        }

        return ventas;
    }

    //Consultar por cliente
    public List<Venta> consultarPorCliente(int clienteId) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        List<Venta> ventas = new ArrayList<>();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, FECHA_HORA, CLIENTE_ID, VENDEDOR_ID,ESPECTACULO_ID, UBICACION_ID, CANTIDAD, TOTAL FROM VENTA WHERE CLIENTE_ID = ?");
            preparedStatement.setInt(1, clienteId);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next())
            {
                Venta venta = new Venta();
                venta.setId(rs.getInt("ID"));
                venta.setFechaHora(rs.getTimestamp("FECHA_HORA"));

                int idCliente = rs.getInt("CLIENTE_ID");
                int idVendedor = rs.getInt("VENDEDOR_ID");
                int idEspectaculo = rs.getInt("ESPECTACULO_ID");
                int idUbicacion = rs.getInt("UBICACION_ID");

                Usuario cliente = daoUsuario.consultar(idCliente);
                Usuario vendedor = daoUsuario.consultar(idVendedor);
                Espectaculo espectaculo = daoEspectaculo.consultar(idEspectaculo);
                UbicacionEntrada ubicacion = daoUbicacionEntrada.consultar(idUbicacion);

                venta.setCliente(cliente);
                venta.setVendedor(vendedor);
                venta.setEspectaculo(espectaculo);
                venta.setUbicacion(ubicacion);
                venta.setCantidad(rs.getInt("CANTIDAD"));
                venta.setTotal(rs.getFloat("TOTAL"));

                ventas.add(venta);
            }
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error en la consulta de ventas por cliente. aca " + e.getMessage());
        }

        return ventas;
    }

    public void actualizarVendedor(int idVenta, int idVendedor) throws DaoException
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("UPDATE VENTA SET VENDEDOR_ID = ? WHERE ID = ?");
            preparedStatement.setInt(1, idVendedor);
            preparedStatement.setInt(2, idVenta);

            preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al actualizar vendedor de la venta: " + e.getMessage());
        }
    }


    public List<Object[]> reportePorEspectaculo(Timestamp desde, Timestamp hasta) throws DaoException
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List<Object[]> lista = new ArrayList<>();

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "SELECT e.TITULO, " +"SUM(v.CANTIDAD) AS TOTAL_CANTIDAD, SUM(v.TOTAL) AS TOTAL_IMPORTE FROM VENTA v JOIN ESPECTACULO e ON v.ESPECTACULO_ID = e.ID WHERE v.FECHA_HORA BETWEEN ? AND ? GROUP BY e.TITULO ORDER BY e.TITULO";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setTimestamp(1, desde);
            preparedStatement.setTimestamp(2, hasta);

            rs = preparedStatement.executeQuery();

            while (rs.next()) 
            {
                String titulo = rs.getString("TITULO");
                int cantidad = rs.getInt("TOTAL_CANTIDAD");
                float total = rs.getFloat("TOTAL_IMPORTE");
                lista.add(new Object[]{ titulo, cantidad, total });
            }
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error en reporte de ventas: " + e.getMessage());
        }
        finally 
        {
            try 
            {
                if (rs != null) rs.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException ignore) { }
        }

        return lista;
    }

    // Entradas permitidas por espectaculo
    public int contarEntradasPorEspectaculo(int idEspectaculo) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String sql = "SELECT COALESCE(SUM(CANTIDAD), 0) AS total FROM VENTA WHERE ESPECTACULO_ID = ?";
        try
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, idEspectaculo);
            rs = preparedStatement.executeQuery();

            if (rs.next()) 
            {
                return rs.getInt("total");
            }
            return 0;

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al contar entradas por espectáculo" +e.getMessage());
        } 
    }

    // Entradas permitidas por ubicacion
    public int contarEntradasPorEspectaculoYUbicacion(int idEspectaculo, int idUbicacion) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        String sql = "SELECT COALESCE(SUM(CANTIDAD), 0) AS total FROM VENTA WHERE ESPECTACULO_ID = ? AND UBICACION_ID = ?";

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, idEspectaculo);
            preparedStatement.setInt(2, idUbicacion);
            rs = preparedStatement.executeQuery();

            if (rs.next()) 
            {
                return rs.getInt("total");
            }
            return 0;

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al contar entradas por espectáculo y ubicación" +e.getMessage());
        } 
    }
   
}


