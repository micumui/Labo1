package dao;

import entidades.Espectaculo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoEspectaculo implements IDAO<Espectaculo>{

    private String DB_JDBC_DRIVER="org.h2.Driver";
    private String DB_URL="jdbc:h2:~/test";
    private String DB_USER="sa";
    private String DB_PASSWORD="";

    
    //Insertar en tabla
    @Override
    public void insertar(Espectaculo elemento) throws DaoException
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("se conecto");
            preparedStatement = connection.prepareStatement("INSERT INTO ESPECTACULO (TITULO,FECHA_HORA,PRECIO_BASE,ESTADIO_ID,POSTER) VALUES(?,?,?,?,?)");
            preparedStatement.setString(1, elemento.getTitulo());
            preparedStatement.setTimestamp(2,elemento.getFechaHora());
            preparedStatement.setFloat(3,elemento.getPrecio());
            preparedStatement.setInt(4,elemento.getEstadio().getId());
            preparedStatement.setString(5,elemento.getPoster());

            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {

            throw  new DaoException("Fallo la base de datos." +e.getMessage());
        }

    }

    //Modificar
    @Override
    public void modificar(Espectaculo elemento) throws DaoException
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Se conecto");
            preparedStatement = connection.prepareStatement("UPDATE ESPECTACULO SET TITULO=?,FECHA_HORA=?,PRECIO_BASE=?,ESTADIO_ID=?,POSTER=? WHERE ID=?");
            preparedStatement.setString(1, elemento.getTitulo());
            preparedStatement.setTimestamp(2,elemento.getFechaHora());
            preparedStatement.setFloat(3,elemento.getPrecio());
            preparedStatement.setInt(4,elemento.getEstadio().getId());
            preparedStatement.setString(5,elemento.getPoster());
            preparedStatement.setInt(6,elemento.getId());

            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Fallo aca!!."+e.getMessage());
        }
    }

    //Eliminar    
    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatementCheck = null;
        PreparedStatement preparedStatementDelete = null;
        ResultSet rs = null;

        String SQL_CHECK = "SELECT COUNT(*) FROM venta WHERE espectaculo_id = ?";
        String SQL_DELETE = "DELETE FROM espectaculo WHERE id = ?";

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatementCheck = connection.prepareStatement(SQL_CHECK);
            preparedStatementCheck.setInt(1, id);
            rs = preparedStatementCheck.executeQuery();

            int cantidadVentas = 0;
            if (rs.next()) 
            {
                cantidadVentas = rs.getInt(1);
            }

            if (cantidadVentas > 0) 
            {
            
                throw new DaoException("No se puede eliminar el espectáculo porque tiene " +cantidadVentas + " venta(s) asociada(s).");
            }
            preparedStatementDelete = connection.prepareStatement(SQL_DELETE);
            preparedStatementDelete.setInt(1, id);
            preparedStatementDelete.executeUpdate();

        } catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Fallo la base de datos: " + e.getMessage());
        } 
    }

    //Consultar uno
    @Override
    public Espectaculo consultar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        Espectaculo espectaculo = new Espectaculo();
        DaoEstadio daoEstadio = new DaoEstadio();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,TITULO,PRECIO_BASE,FECHA_HORA,ESTADIO_ID,POSTER FROM ESPECTACULO WHERE ID=?");
            preparedStatement.setInt(1, id);
            ResultSet rs=preparedStatement.executeQuery();
            if (rs.next())
            {
                espectaculo.setId(rs.getInt("ID"));
                espectaculo.setTitulo(rs.getString("Titulo"));
                espectaculo.setPrecio(rs.getFloat("precio_base"));
                espectaculo.setFechaHora(rs.getTimestamp("fecha_hora"));
                espectaculo.setPoster(rs.getString("Poster"));
                
                int idEstadio = rs.getInt("ESTADIO_ID");
                espectaculo.setEstadio(daoEstadio.consultar(idEstadio));
            }
         }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta. espectaculo " +e.getMessage());
        }
        return espectaculo;
    }

    //Consultar toda la tabla
    @Override
    public List<Espectaculo> consultarTodos() throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        List<Espectaculo> espectaculos = new ArrayList<>();
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,TITULO,PRECIO_BASE,FECHA_HORA,ESTADIO_ID,POSTER FROM ESPECTACULO");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next())
            {   Espectaculo espectaculo = new Espectaculo();
                DaoEstadio daoEstadio = new DaoEstadio();
     
                espectaculo.setId(rs.getInt("ID"));
                espectaculo.setTitulo(rs.getString("Titulo"));
                espectaculo.setPrecio(rs.getFloat("precio_base"));
                espectaculo.setFechaHora(rs.getTimestamp("fecha_hora"));
                espectaculo.setPoster(rs.getString("Poster"));
                
                int idEst = rs.getInt("ESTADIO_ID");
                espectaculo.setEstadio(daoEstadio.consultar(idEst));

                espectaculos.add(espectaculo);
            }
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta. espectaculo 2"+e.getMessage());
        }
        return espectaculos;
    }






    
}
