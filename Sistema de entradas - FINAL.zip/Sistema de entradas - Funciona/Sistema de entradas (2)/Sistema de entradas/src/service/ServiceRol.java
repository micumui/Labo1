package service;

import dao.DaoException;
import dao.DaoRol;
import entidades.Rol;

public class ServiceRol {
    private DaoRol daoRol;

    public ServiceRol()
    {
        daoRol = new DaoRol();
    }

    public void insertar(Rol rol) throws ServiceException
    {
        try
        {
            daoRol.insertar(rol);
        }
        catch(DaoException e)
        {
            throw new ServiceException("Error en la base de datos. ");
        }

    }
    
}