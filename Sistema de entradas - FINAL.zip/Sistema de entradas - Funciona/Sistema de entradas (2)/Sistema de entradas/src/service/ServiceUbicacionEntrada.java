package service;

import dao.DaoException;
import dao.DaoUbicacionEntrada;
import entidades.UbicacionEntrada;

import java.util.List;

public class ServiceUbicacionEntrada {

    private DaoUbicacionEntrada daoUbicacionEntrada;

    public ServiceUbicacionEntrada() {
        daoUbicacionEntrada = new DaoUbicacionEntrada();
    }

    public UbicacionEntrada buscarPorId(int id) throws DaoException {
        return daoUbicacionEntrada.consultar(id);
    }

    public List<UbicacionEntrada> listarPorEstadio(int idEstadio) throws DaoException {
        return daoUbicacionEntrada.consultarPorEstadio(idEstadio);
    }

    public List<UbicacionEntrada> listarTodas() throws DaoException {
        return daoUbicacionEntrada.consultarTodos();
    }
}
