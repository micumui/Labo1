package service;

import dao.*;
import entidades.Espectaculo;
import entidades.UbicacionEntrada;
import entidades.Usuario;
import entidades.Venta;

import java.sql.Timestamp;
import java.util.List;

public class ServiceVenta {

    private DaoVenta daoVenta;
    private DaoUsuario daoUsuario;
    private DaoEspectaculo daoEspectaculo;
    private DaoUbicacionEntrada daoUbicacionEntrada;

    public ServiceVenta() 
    {
        daoVenta = new DaoVenta();
        daoUsuario = new DaoUsuario();
        daoEspectaculo = new DaoEspectaculo();
        daoUbicacionEntrada = new DaoUbicacionEntrada();
    }


    public void registrarVentaCliente(int idCliente,int idEspectaculo,int idUbicacion,int cantidad) throws DaoException 
    {

        if (cantidad <= 0) 
        {
            throw new DaoException("La cantidad debe ser mayor a cero.");
        }

        Usuario cliente = daoUsuario.consultar(idCliente);
        if (cliente == null) 
        {
            throw new DaoException("El cliente no existe.");
        }

        Espectaculo espectaculo = daoEspectaculo.consultar(idEspectaculo);
        if (espectaculo == null) 
        {
            throw new DaoException("El espectáculo no existe.");
        }

        UbicacionEntrada ubicacion = daoUbicacionEntrada.consultar(idUbicacion);
        if (ubicacion == null)
        {
            throw new DaoException("La ubicación no existe.");
        }

        Usuario vendedor = cliente;
        float total = calcularTotalPorUbicacion(ubicacion, cantidad);

        Venta venta = new Venta();
        venta.setFechaHora(new Timestamp(System.currentTimeMillis()));
        venta.setCliente(cliente);
        venta.setVendedor(vendedor);
        venta.setEspectaculo(espectaculo);
        venta.setUbicacion(ubicacion);
        venta.setCantidad(cantidad);
        venta.setTotal(total);

        daoVenta.insertar(venta);
    }

    public void registrarVentaVendedor(int idVendedor,int idCliente,int idEspectaculo,int idUbicacion,int cantidad) throws DaoException 
    {

        if (cantidad <= 0) 
        {
            throw new DaoException("La cantidad debe ser mayor a cero.");
        }

        Usuario vendedor = daoUsuario.consultar(idVendedor);
        if (vendedor == null)
        {
            throw new DaoException("El vendedor no existe.");
        }

        Usuario cliente = daoUsuario.consultar(idCliente);
        if (cliente == null) 
        {
            throw new DaoException("El cliente no existe.");
        }

        Espectaculo espectaculo = daoEspectaculo.consultar(idEspectaculo);
        if (espectaculo == null) 
        {
            throw new DaoException("El espectáculo no existe.");
        }

        UbicacionEntrada ubicacion = daoUbicacionEntrada.consultar(idUbicacion);
        if (ubicacion == null) 
        {
            throw new DaoException("La ubicación no existe.");
        }

        float total = calcularTotalPorUbicacion(ubicacion, cantidad);

        Venta venta = new Venta();
        venta.setFechaHora(new Timestamp(System.currentTimeMillis()));
        venta.setCliente(cliente);
        venta.setVendedor(vendedor);
        venta.setEspectaculo(espectaculo);
        venta.setUbicacion(ubicacion);
        venta.setCantidad(cantidad);
        venta.setTotal(total);

        daoVenta.insertar(venta);
    }



    public List<Venta> listarVentas() throws DaoException 
    {
        return daoVenta.consultarTodos();
    }

    public List<Venta> listarVentasDeCliente(int idCliente) throws DaoException 
    {
        return daoVenta.consultarPorCliente(idCliente);
    }

    public void devolverVenta(int idVenta) throws DaoException 
    {
        daoVenta.eliminar(idVenta);
    }



    public float calcularTotalPorUbicacion(UbicacionEntrada ubicacion,int cantidad) throws DaoException 
    {

        if (ubicacion == null) 
        {
            throw new DaoException("Ubicación nula al calcular total.");
        }
        if (cantidad <= 0) 
        {
            throw new DaoException("La cantidad debe ser mayor a cero.");
        }

        float precioUnitario = ubicacion.getPrecio();
        return precioUnitario * cantidad;
    }


    public float calcularTotalPorUbicacion(int idUbicacion,int cantidad) throws DaoException 
    {
        UbicacionEntrada ubicacion = daoUbicacionEntrada.consultar(idUbicacion);
        return calcularTotalPorUbicacion(ubicacion, cantidad);
    }

    //Reporte de ventas
    public List<Object[]> reportePorEspectaculo(java.util.Date fechaDesde,java.util.Date fechaHasta) throws DaoException 
    {
        if (fechaDesde == null || fechaHasta == null) 
        {
            throw new DaoException("Las fechas no pueden ser nulas.");
        }

        Timestamp tsDesde = new Timestamp(fechaDesde.getTime());
        Timestamp tsHasta = new Timestamp(fechaHasta.getTime());

        return daoVenta.reportePorEspectaculo(tsDesde, tsHasta);
    }

    //Capacidad en el esradio   
    public boolean hayCapacidadEnEstadio(Espectaculo espectaculo,int cantidadNueva) throws DaoException 
    {
        int idEspectaculo = espectaculo.getId();
        int capacidadEstadio = espectaculo.getEstadio().getCapacidad();
        int vendidas = daoVenta.contarEntradasPorEspectaculo(idEspectaculo);
        int totalLuego = vendidas + cantidadNueva;
        return totalLuego <= capacidadEstadio;
    }

    //Capacidad en las ubicaciones
    public boolean hayCapacidadEnUbicacion(Espectaculo espectaculo,UbicacionEntrada ubicacion,int cantidadNueva) throws DaoException 
    {
        int idEspectaculo = espectaculo.getId();
        int idUbicacion = ubicacion.getId();
        int capacidadUbicacion = ubicacion.getCapacidad();
        int vendidasUbicacion = daoVenta.contarEntradasPorEspectaculoYUbicacion(idEspectaculo, idUbicacion);
        int totalLuego = vendidasUbicacion + cantidadNueva;
        return totalLuego <= capacidadUbicacion;
    }
}
