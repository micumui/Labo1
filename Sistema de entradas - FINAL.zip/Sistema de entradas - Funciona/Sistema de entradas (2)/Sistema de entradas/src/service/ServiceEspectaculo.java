package service;

import dao.DaoEspectaculo;
import dao.DaoException;
import entidades.Espectaculo;

import java.util.List;

public class ServiceEspectaculo {

    private DaoEspectaculo daoEspectaculo;

    public ServiceEspectaculo() 
    {
        daoEspectaculo = new DaoEspectaculo();
    }

    public List<Espectaculo> listarEspectaculos() throws DaoException 
    {
        return daoEspectaculo.consultarTodos();
    }

    public Espectaculo buscarPorId(int id) throws DaoException 
    {
        return daoEspectaculo.consultar(id);
    }

    public void guardarEspectaculo(Espectaculo espectaculo) throws DaoException 
    {
        if (espectaculo == null) 
        {
            throw new DaoException("El espectáculo no puede ser nulo.");
        }
        if (espectaculo.getTitulo() == null || espectaculo.getTitulo().trim().isEmpty()) 
        {
            throw new DaoException("El espectáculo debe tener un título.");
        }
        if (espectaculo.getEstadio() == null) 
        {
            throw new DaoException("El espectáculo debe tener un estadio asignado.");
        }
 
    }
}
