package service;


import java.util.ArrayList;
import java.util.List;

import dao.DaoException;
import dao.DaoUsuario;
import dao.DaoRol;
import entidades.Rol;
import entidades.Usuario;

public class ServiceUsuario {
    
    private DaoUsuario daoUsuario;
    private DaoRol daoRol;

    public ServiceUsuario()
    {
        daoUsuario = new DaoUsuario();
        daoRol = new DaoRol();
    }

    public void insertar(Usuario usuario) throws ServiceException
    {
        try{
            daoUsuario.insertar(usuario);
        }
        catch(DaoException e)
        {
            throw new ServiceException("Error en la base de datos. ");
        }

    }

    public Usuario login(String mail, String clave) throws ServiceException 
    {
        try 
        {
            return daoUsuario.buscarPorMailYClave(mail, clave);
        } 
        catch (DaoException e) 
        {
            throw new ServiceException("Error en login: " + e.getMessage());
        }
    }

  public Usuario registrarCliente(String nombre, String mail, String clave) throws ServiceException 
  {
        try 
        {
            Rol rolCliente = daoRol.buscarPorNombre("CLIENTE");
            if (rolCliente == null) 
            {
                throw new ServiceException("No se encontró el rol CLIENTE.");
            }

            Usuario usuario = new Usuario();
            usuario.setNombre(nombre);
            usuario.setMail(mail);
            usuario.setClave(clave);
            usuario.setRol(rolCliente);

            daoUsuario.insertar(usuario);
            return usuario;

        } 
        catch (DaoException e) 
        {
            throw new ServiceException("Error al registrar cliente: " + e.getMessage());
        }
    }   

    public Usuario registrarAdminOVendedor(String nombre, String mail, String nombreRol) throws ServiceException 
    {
        try
        {
            Rol rol = daoRol.buscarPorNombre(nombreRol);
            if (rol == null)
            {
                throw new ServiceException("No se encontró el rol " + nombreRol);
            }

            Usuario usuario = new Usuario();
            usuario.setNombre(nombre);
            usuario.setMail(mail);

            // Clave default según el rol
            if ("ADMINISTRADOR".equalsIgnoreCase(nombreRol)) 
            {
                usuario.setClave("admin");      
            } 
            else if ("VENDEDOR".equalsIgnoreCase(nombreRol))
            {
                usuario.setClave("ven");  
            } 
            else 
            {
                usuario.setClave("default");
            }

            usuario.setRol(rol);

            daoUsuario.insertar(usuario);
            return usuario;

        } 
        catch (DaoException e) 
        {
            throw new ServiceException("Error al registrar usuario de administración: " + e.getMessage());
        }
    }

        public Usuario buscarPorId(int id) throws ServiceException 
    {
        try 
        {
            return daoUsuario.consultar(id);
        } 
        catch (DaoException e) 
        {
            throw new ServiceException("Error al buscar usuario por id: " + e.getMessage());
        }
    }

    public List<Usuario> listarTodos() throws ServiceException
    {
        try 
        {
            return daoUsuario.consultarTodos();
        } 
        catch (DaoException e) 
        {
            throw new ServiceException("Error al listar usuarios: " + e.getMessage());
        }
    }

    public List<Usuario> listarClientes() throws ServiceException
    {
        try 
        {
            List<Usuario> todos = daoUsuario.consultarTodos();
            List<Usuario> clientes = new ArrayList<>();

            for (Usuario u : todos) 
            {
                if (u.getRol() != null && 
                    "CLIENTE".equalsIgnoreCase(u.getRol().getNombre())) 
                {
                    clientes.add(u);
                }
            }

            return clientes;
        } 
        catch (DaoException e) 
        {
            throw new ServiceException("Error al listar clientes: " + e.getMessage());
        }
    }




}
