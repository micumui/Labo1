package dao;

import entidades.Usuario;
import entidades.Rol;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoUsuario implements IDAO<Usuario> {

    private String DB_JDBC_DRIVER = "org.h2.Driver";
    private String DB_URL = "jdbc:h2:~/test";
    private String DB_USER = "sa";
    private String DB_PASSWORD = "";

    private DaoRol daoRol = new DaoRol();

    //Insertar
    @Override
    public void insertar(Usuario elemento) throws DaoException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("INSERT INTO USUARIO (NOMBRE, CLAVE, MAIL, ROL_ID) VALUES (?,?,?,?)");

            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getClave());
            preparedStatement.setString(3, elemento.getMail());
            preparedStatement.setInt(4, elemento.getRol().getId());   // FK a ROL

            preparedStatement.executeUpdate();

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al insertar usuario: " + e.getMessage());
        }
    }

    //Modificar
    @Override
    public void modificar(Usuario elemento) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("UPDATE USUARIO SET NOMBRE=?, CLAVE=?, MAIL=?, ROL_ID=? WHERE ID=?");

            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getClave());
            preparedStatement.setString(3, elemento.getMail());
            preparedStatement.setInt(4, elemento.getRol().getId());
            preparedStatement.setInt(5, elemento.getId());

            preparedStatement.executeUpdate();

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al modificar usuario: " + e.getMessage());
        }
    }

    //Eliminar
    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("DELETE FROM USUARIO WHERE ID=?");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al eliminar usuario: " + e.getMessage());
        }
    }

    //Consultar 1
    @Override
    public Usuario consultar(int id) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        Usuario usuario = new Usuario();
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, NOMBRE, CLAVE, MAIL, ROL_ID FROM USUARIO WHERE ID=?");
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) 
            {
                usuario.setId(rs.getInt("ID"));
                usuario.setNombre(rs.getString("NOMBRE"));
                usuario.setClave(rs.getString("CLAVE"));
                usuario.setMail(rs.getString("MAIL"));

                int rolId = rs.getInt("ROL_ID");
                Rol rol = daoRol.consultar(rolId);
                usuario.setRol(rol);
            }

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al consultar usuario: " + e.getMessage());
        }

        return usuario;
    }

    //Consultar todos
    @Override
    public List<Usuario> consultarTodos() throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        List<Usuario> usuarios = new ArrayList<>();
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, NOMBRE, CLAVE, MAIL, ROL_ID FROM USUARIO");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) 
            {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("ID"));
                usuario.setNombre(rs.getString("NOMBRE"));
                usuario.setClave(rs.getString("CLAVE"));
                usuario.setMail(rs.getString("MAIL"));

                int rolId = rs.getInt("ROL_ID");
                Rol rol = daoRol.consultar(rolId);
                usuario.setRol(rol);

                usuarios.add(usuario);
            }

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al consultar usuarios: " + e.getMessage());
        }

        return usuarios;
    }

    public Usuario buscarPorMailYClave(String mail, String clave) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Usuario usuario = new Usuario();

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, NOMBRE, CLAVE, MAIL, ROL_ID FROM USUARIO WHERE MAIL = ? AND CLAVE = ?");
            preparedStatement.setString(1, mail);
            preparedStatement.setString(2, clave);

            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) 
            {
        
                usuario.setId(rs.getInt("ID"));
                usuario.setNombre(rs.getString("NOMBRE"));
                usuario.setClave(rs.getString("CLAVE"));
                usuario.setMail(rs.getString("MAIL"));

                int rolId = rs.getInt("ROL_ID");
                Rol rol = daoRol.consultar(rolId);
                usuario.setRol(rol);
            }

    } 
    catch (ClassNotFoundException | SQLException e) 
    {
        throw new DaoException("Error al buscar usuario: " + e.getMessage());
    }

    return usuario; 
    }

}
