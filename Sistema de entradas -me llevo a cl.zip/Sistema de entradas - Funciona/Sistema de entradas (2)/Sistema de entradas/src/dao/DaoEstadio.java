package dao;

import entidades.Estadio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class DaoEstadio implements IDAO<Estadio>{

    
    DaoUbicacionEntrada daoUbicacion = new DaoUbicacionEntrada();
    DaoEspectaculo daoEspectaculo = new DaoEspectaculo();

    private String DB_JDBC_DRIVER="org.h2.Driver";
    private String DB_URL="jdbc:h2:~/test";
    private String DB_USER="sa";
    private String DB_PASSWORD="";


    //Insertar en tabla

    @Override
    public void insertar(Estadio elemento) throws DaoException
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("se conecto");
            preparedStatement = connection.prepareStatement("INSERT INTO ESTADIO (NOMBRE,DIRECCION,CAPACIDAD) VALUES(?,?,?)");
            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getDireccion());
            preparedStatement.setInt(3,elemento.getCapacidad());

            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {

            throw  new DaoException("Fallo la base de datos." +e.getMessage());
        }

    }

    // Modificar en la tabala

    @Override
    public void modificar(Estadio elemento) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE ESTADIO SET DIRECCION=?,NOMBRE=?,CAPACIDAD=? WHERE ID=?");
            preparedStatement.setString(1, elemento.getDireccion());
            preparedStatement.setString(2, elemento.getNombre());
            preparedStatement.setInt(3,elemento.getCapacidad());
            preparedStatement.setInt(4, elemento.getId());
            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw  new DaoException("Fallo la base de datos.");
        }
    }

    // Eliminar en la tabla

    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("DELETE FROM ESTADIO WHERE ID=?");
            preparedStatement.setInt(1, id);
            int resultado = preparedStatement.executeUpdate();
        }
        catch(ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Fallo la base de datos.");
        }

    }

    //Consultar 1
    @Override
    public Estadio consultar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        Estadio estadio = new Estadio();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,NOMBRE,DIRECCION,CAPACIDAD FROM ESTADIO WHERE ID=?");
            preparedStatement.setInt(1, id);
            ResultSet rs=preparedStatement.executeQuery();
            if (rs.next())
            {
                estadio.setId(rs.getInt("ID"));
                estadio.setNombre(rs.getString("Nombre"));
                estadio.setDireccion(rs.getString("Direccion"));
                estadio.setCapacidad(rs.getInt("Capacidad"));
            }
         }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta.");
        }
        return estadio;
    }


    //Consultar todos
    @Override
     public List<Estadio> consultarTodos() throws DaoException {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        List<Estadio> estadios = new ArrayList<>();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,NOMBRE,DIRECCION,CAPACIDAD FROM ESTADIO");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next())
            {   Estadio estadio = new Estadio();
                estadio.setId(rs.getInt("ID"));
                estadio.setNombre(rs.getString("Nombre"));
                estadio.setDireccion(rs.getString("Direccion"));
                estadio.setCapacidad(rs.getInt("Capacidad"));
                estadios.add(estadio);
            }
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta."+e.getMessage());
        }
        return estadios;
    }

}
