package dao;

import entidades.Rol;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoRol implements IDAO<Rol> {

    private String DB_JDBC_DRIVER = "org.h2.Driver";
    private String DB_URL = "jdbc:h2:~/test";
    private String DB_USER = "sa";
    private String DB_PASSWORD = "";

    //Insertar
    @Override
    public void insertar(Rol elemento) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("INSERT INTO ROL (NOMBRE, DESCRIPCION) VALUES (?,?)");
            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getDescripcion());

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al insertar rol: " + e.getMessage());
        }
    }

    //Modificar
    @Override
    public void modificar(Rol elemento) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("UPDATE ROL SET NOMBRE=?, DESCRIPCION=? WHERE ID=?");
            preparedStatement.setString(1, elemento.getNombre());
            preparedStatement.setString(2, elemento.getDescripcion());
            preparedStatement.setInt(3, elemento.getId());
            

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al modificar rol: " + e.getMessage());
        }
    }

    //Eliminar
    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("DELETE FROM ROL WHERE ID=?");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        } 
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error al eliminar rol: " + e.getMessage());
        }
    }

    //Consultar 1
    @Override
    public Rol consultar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        Rol rol = null;

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            preparedStatement = connection.prepareStatement("SELECT ID, NOMBRE, DESCRIPCION FROM ROL WHERE ID=?");
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) 
            {
                rol = new Rol();
                rol.setId(rs.getInt("ID"));
                rol.setNombre(rs.getString("NOMBRE"));
                rol.setDescripcion(rs.getString("DESCRIPCION"));
            }

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al consultar rol: " + e.getMessage());
        }

        return rol;
    }


    //Consultar todos
    @Override
    public List<Rol> consultarTodos() throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        List<Rol> roles = new ArrayList<>();

        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID, NOMBRE, DESCRIPCION FROM ROL");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) 
            {
                Rol rol = new Rol();
                rol.setId(rs.getInt("ID"));
                rol.setNombre(rs.getString("NOMBRE"));
                rol.setDescripcion(rs.getString("DESCRIPCION"));
                roles.add(rol);
            }

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error al consultar roles: " + e.getMessage());
        }

        return roles;
    }
}
