package dao;

import entidades.Estadio;

public class Prueba {
    public static void main(String[] args) {

        DaoEstadio dao = new DaoEstadio();

        try{
            Estadio estadio1 = new Estadio();
            estadio1.setNombre("Movistar arena");
            estadio1.setDireccion("Humboldt 450");
            dao.insertar(estadio1);
            System.out.println("Todo bien!!");

        }
        catch(DaoException e)
        {
            System.out.println("Error." + e.getMessage());
            e.printStackTrace();
        }
    }

      
}

