
package dao;

import entidades.UbicacionEntrada;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaoUbicacionEntrada implements IDAO<UbicacionEntrada>{

    private String DB_JDBC_DRIVER="org.h2.Driver";
    private String DB_URL="jdbc:h2:~/test";
    private String DB_USER="sa";
    private String DB_PASSWORD="";

    
    //Insertar en tabla

    @Override
    public void insertar(UbicacionEntrada elemento) throws DaoException
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("se conecto");
            preparedStatement = connection.prepareStatement("INSERT INTO UBICACIONENTRADA (CAPACIDAD,PRECIO,nombre,ESTADIO_ID) VALUES(?,?,?,?)");
            preparedStatement.setInt(1, elemento.getCapacidad());
            preparedStatement.setFloat(2, elemento.getPrecio());
            preparedStatement.setString(3,elemento.getnombre());
            preparedStatement.setInt(4,elemento.getEstadio().getId());

            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {

            throw  new DaoException("Fallo la base de datos." +e.getMessage());
        }

    }

    // Modificar en la tabala

    @Override
    public void modificar(UbicacionEntrada elemento) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("UPDATE UBICACIONENTRADA SET CAPACIDAD=?,PRECIO=?,nombre=?,ESTADIO_ID=? WHERE ID=?");
            preparedStatement.setInt(1, elemento.getCapacidad());
            preparedStatement.setFloat(2, elemento.getPrecio());
            preparedStatement.setString(3,elemento.getnombre());
            preparedStatement.setInt(4,elemento.getEstadio().getId());
            preparedStatement.setInt(5, elemento.getId());
            int resultado = preparedStatement.executeUpdate();
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw  new DaoException("Fallo la base de datos.");
        }
    }

    // Eliminar en la tabla

    @Override
    public void eliminar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("DELETE FROM UBICACIONENTRADA WHERE ID=?");
            preparedStatement.setInt(1, id);
            int resultado = preparedStatement.executeUpdate();
        }
        catch(ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Fallo la base de datos."+e.getMessage());
        }

    }

    //Elimino las ubicaciones de un estadio
    public void eliminarDeEstadio(int idEstadio) throws DaoException 
    {
        Connection connection = null;
        PreparedStatement ps = null;
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            ps = connection.prepareStatement("DELETE FROM UBICACIONENTRADA WHERE ESTADIO_ID = ?");
            ps.setInt(1, idEstadio);
            ps.executeUpdate();

        } 
        catch (ClassNotFoundException | SQLException e) 
        {
        throw new DaoException("Error al eliminar ubicaciones del estadio: " + e.getMessage());
        }
    }


    //Consultar uno
    @Override
    public UbicacionEntrada consultar(int id) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        UbicacionEntrada ubicacionEntrada = new UbicacionEntrada();
        DaoEstadio daoEstadio = new DaoEstadio();
        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,CAPACIDAD,PRECIO,nombre,ESTADIO_ID FROM UBICACIONENTRADA WHERE ID=?");
            preparedStatement.setInt(1, id);
            ResultSet rs=preparedStatement.executeQuery();
            if (rs.next())
            {
                ubicacionEntrada.setId(rs.getInt("ID"));
                ubicacionEntrada.setnombre(rs.getString("Nombre ubicacion"));
                ubicacionEntrada.setCapacidad(rs.getInt("Capacidad"));
                ubicacionEntrada.setPrecio(rs.getFloat("Precio"));
                
                int idEstadio = rs.getInt("ESTADIO_ID");
                ubicacionEntrada.setEstadio(daoEstadio.consultar(idEstadio));
            }
         }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta.");
        }
        return ubicacionEntrada;
    }


    //Consultar desde la tabla

    @Override
    public List<UbicacionEntrada> consultarTodos() throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        List<UbicacionEntrada> ubicacionEntradas = new ArrayList<>();
        try 
        {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,CAPACIDAD,PRECIO,NOMBRE,ESTADIO_ID FROM ubicacionEntrada");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next())
            {   UbicacionEntrada ubicacionEntrada = new UbicacionEntrada();
                DaoEstadio daoEstadio = new DaoEstadio();
                ubicacionEntrada.setId(rs.getInt("ID"));
                ubicacionEntrada.setCapacidad(rs.getInt("CAPACIDAD"));
                ubicacionEntrada.setPrecio(rs.getFloat("PRECIO"));
                ubicacionEntrada.setnombre(rs.getString("NOMBRE"));
                
                int idEst = rs.getInt("ESTADIO_ID");
                ubicacionEntrada.setEstadio(daoEstadio.consultar(idEst));

                ubicacionEntradas.add(ubicacionEntrada);
            }
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new DaoException("Error en la consulta."+e.getMessage());
        }
        return ubicacionEntradas;
    }

    //Consulto por las ubicaciones de un estadio 

    public List<UbicacionEntrada> consultarPorEstadio(int idEstadio) throws DaoException 
    {
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        List<UbicacionEntrada> ubicacionEntradas = new ArrayList<>();

        try {
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT ID,CAPACIDAD,PRECIO,NOMBRE,ESTADIO_ID FROM UBICACIONENTRADA WHERE ESTADIO_ID=?");
            preparedStatement.setInt(1, idEstadio);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) 
            {
                UbicacionEntrada ubicacionEntrada = new UbicacionEntrada();
                DaoEstadio daoEstadio = new DaoEstadio();
                ubicacionEntrada.setId(rs.getInt("ID"));
                ubicacionEntrada.setCapacidad(rs.getInt("CAPACIDAD"));
                ubicacionEntrada.setPrecio(rs.getFloat("PRECIO"));
                ubicacionEntrada.setnombre(rs.getString("NOMBRE"));
                

                int idEst = rs.getInt("ESTADIO_ID");
                ubicacionEntrada.setEstadio(daoEstadio.consultar(idEst));

                ubicacionEntradas.add(ubicacionEntrada);
            }
        }
        catch (ClassNotFoundException | SQLException e) 
        {
            throw new DaoException("Error en la consulta."+e.getMessage());
        }
        return ubicacionEntradas;
    }
    
}
