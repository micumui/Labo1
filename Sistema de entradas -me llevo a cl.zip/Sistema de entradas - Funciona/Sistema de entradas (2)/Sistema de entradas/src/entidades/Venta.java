package entidades;

public class Venta {
    
    int id;
    int cantidad;
    int precioUnitario;
    int total;
    int idEspectaculo;
    int idCliente;
    int idVendedor;
    int idUbicacionEntrada;
    
    //Constructores
    public Venta() 
    {
    }

    public Venta(int id, int cantidad, int precioUnitario, int total, int idEspectaculo, int idCliente, int idVendedor, int idUbicacionEntrada) 
    {
        this.id = id;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.total = total;
        this.idEspectaculo = idEspectaculo;
        this.idCliente = idCliente;
        this.idVendedor = idVendedor;
        this.idUbicacionEntrada = idUbicacionEntrada;
    }

    //Getters
    public int getId() 
    {
        return id;
    }
    public int getCantidad() 
    {
        return cantidad;
    }
    public int getPrecioUnitario() 
    {
        return precioUnitario;
    }
    public int getTotal() 
    {
        return total;
    }
    public int getIdEspectaculo() 
    {
        return idEspectaculo;
    }
    public int getIdCliente() 
    {
        return idCliente;
    }
    public int getIdVendedor() 
    {
        return idVendedor;
    }
    public int getIdUbicacionEntrada() 
    {
        return idUbicacionEntrada;
    }

    
    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setCantidad(int cantidad) 
    {
        this.cantidad = cantidad;
    }
    public void setPrecioUnitario(int precioUnitario) 
    {
        this.precioUnitario = precioUnitario;
    }
    public void setTotal(int total) 
    {
        this.total = total;
    }
    public void setIdEspectaculo(int idEspectaculo) 
    {
        this.idEspectaculo = idEspectaculo;
    }
    public void setIdCliente(int idCliente) 
    {
        this.idCliente = idCliente;
    }
    public void setIdVendedor(int idVendedor) 
    {
        this.idVendedor = idVendedor;
    }
    public void setIdUbicacionEntrada(int idUbicacionEntrada) 
    {
        this.idUbicacionEntrada = idUbicacionEntrada;
    }

    


    
    
}
