package entidades;

import java.sql.Timestamp;

public class Espectaculo {
    
    int id;
    float precio;
    String titulo;
    Timestamp fechaHora;
    Estadio estadio;


    //Constructores
    public Espectaculo() {
    }

    public Espectaculo(int id, float precio, String titulo, Timestamp fechaHora) {
        this.id = id;
        this.precio = precio;
        this.titulo = titulo;
        this.fechaHora = fechaHora;
    }


    //Getters
    public int getId() 
    {
        return id;
    }
    public float getPrecio() 
    {
        return precio;
    }
    public String getTitulo() 
    {
        return titulo;
    }
    public Timestamp getFechaHora() 
    {
        return fechaHora;
    }
    public Estadio getEstadio()
    {
        return estadio;
    }


    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setPrecio(float precio) 
    {
        this.precio = precio;
    }
    public void setTitulo(String titulo) 
    {
        this.titulo = titulo;
    }
    public void setFechaHora(Timestamp fechaHora) 
    {
        this.fechaHora = fechaHora;
    }
    public void setEstadio(Estadio estadio)
    {
        this.estadio= estadio;
    }


    
    
    





}
