package entidades;

public class Usuario {

    int id;
    String mail;
    String nombre;
    String clave;
    Rol rol;
    
    //Constructores
    public Usuario() 
    {
    }

    public Usuario(int id, String mail, String nombre, String clave) 
    {
        this.id = id;
        this.mail = mail;
        this.nombre = nombre;
        this.clave = clave;
    }


    //Getters
    public int getId() 
    {
        return id;
    }
    public String getMail() 
    {
        return mail;
    }
    public String getNombre()
    {
        return nombre;
    }
    public String getClave() 
    {
        return clave;
    }

    public Rol getRol() 
    {
        return rol;
    }

    //Setters
    public void setId(int id) 
    {
        this.id = id;
    }
    public void setMail(String mail) 
    {
        this.mail = mail;
    }
    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }
    public void setClave(String clave) 
    {
        this.clave = clave;
    }

    public void setRol(Rol rol) 
    {
        this.rol = rol;
    }



    
}
