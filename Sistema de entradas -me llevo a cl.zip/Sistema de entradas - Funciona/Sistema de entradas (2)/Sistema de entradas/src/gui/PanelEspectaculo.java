package gui;

import dao.DaoEspectaculo;
import dao.DaoEstadio;
import dao.DaoException;
import entidades.Espectaculo;
import entidades.Estadio;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class PanelEspectaculo extends JPanel {

    private JComboBox<Estadio> cmbEstadio;
    private JTextField txtTitulo;
    private JTextField txtFechaHora;
    private JTextField txtPrecioBase;
    private JButton btnGuardar;
    private JButton btnEliminar;

    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private DaoEspectaculo daoEspectaculo;
    private DaoEstadio daoEstadio;
    private Integer espectaculoSeleccionadoId = null;

    public PanelEspectaculo() {

        daoEspectaculo = new DaoEspectaculo();
        daoEstadio     = new DaoEstadio();

        Color rosaSuave  = new Color(244, 205, 210);
        Color grisBorde  = new Color(230, 230, 230);
        Color azulTitulo = new Color(5, 51, 66);

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Administración de espectáculos");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        add(panelTitulo, BorderLayout.NORTH);

        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BoxLayout(panelFormulario, BoxLayout.X_AXIS));
        panelFormulario.setBackground(rosaSuave);
        panelFormulario.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel panelAlta = new JPanel(new GridBagLayout());
        panelAlta.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNuevo = new JLabel("Nuevo espectáculo");
        lblNuevo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblNuevo.setForeground(azulTitulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        panelAlta.add(lblNuevo, gbc);

 
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Estadio:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        cmbEstadio = new JComboBox<>();
        cmbEstadio.setPreferredSize(new Dimension(250, 28));
        panelAlta.add(cmbEstadio, gbc);

     
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Título:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        txtTitulo = new JTextField();
        txtTitulo.setPreferredSize(new Dimension(250, 28));
        txtTitulo.setBorder(BorderFactory.createLineBorder(grisBorde, 1));
        panelAlta.add(txtTitulo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Fecha y hora:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        txtFechaHora = new JTextField();
        txtFechaHora.setPreferredSize(new Dimension(200, 28));
        txtFechaHora.setBorder(BorderFactory.createLineBorder(grisBorde, 1));
        txtFechaHora.setToolTipText("Formato: yyyy-MM-dd HH:mm");
        panelAlta.add(txtFechaHora, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelAlta.add(new JLabel("Precio base:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        txtPrecioBase = new JTextField();
        txtPrecioBase.setPreferredSize(new Dimension(150, 28));
        txtPrecioBase.setBorder(BorderFactory.createLineBorder(grisBorde, 1));
        panelAlta.add(txtPrecioBase, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 10, 5, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(new Color(5, 51, 66));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        panelAlta.add(btnGuardar, gbc);

        JPanel panelEliminar = new JPanel();
        panelEliminar.setOpaque(false);
        panelEliminar.setLayout(new BoxLayout(panelEliminar, BoxLayout.Y_AXIS));
        panelEliminar.setBorder(new EmptyBorder(10, 30, 10, 10));

        JLabel lblEliminar = new JLabel("Eliminar espectáculo");
        lblEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblEliminar.setForeground(azulTitulo);
        lblEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel paso1 = new JLabel("1. Seleccioná un espectáculo de la tabla.");
        paso1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        paso1.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel paso2 = new JLabel("2. Hacé clic en Eliminar.");
        paso2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        paso2.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnEliminar.setBackground(new Color(204, 0, 0));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFocusPainted(false);
        btnEliminar.setBorder(BorderFactory.createEmptyBorder(5, 20, 5, 20));
        btnEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelEliminar.add(lblEliminar);
        panelEliminar.add(Box.createVerticalStrut(10));
        panelEliminar.add(paso1);
        panelEliminar.add(paso2);
        panelEliminar.add(Box.createVerticalStrut(20));
        panelEliminar.add(btnEliminar);
        panelEliminar.add(Box.createVerticalGlue());

        panelFormulario.add(panelAlta);
        panelFormulario.add(Box.createHorizontalStrut(30));
        panelFormulario.add(panelEliminar);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Estadio", "Título", "Fecha/Hora", "Precio base"}, 0) 
        {
            @Override
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };

        tabla = new JTable(modeloTabla);
        tabla.setFillsViewportHeight(true);
        tabla.setRowHeight(22);
        tabla.getTableHeader().setReorderingAllowed(false);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(new EmptyBorder(10, 0, 0, 0));

        JPanel panelCentro = new JPanel(new BorderLayout());
        panelCentro.setOpaque(false);
        panelCentro.add(panelFormulario, BorderLayout.NORTH);
        panelCentro.add(scroll, BorderLayout.CENTER);

        add(panelCentro, BorderLayout.CENTER);


        btnGuardar.addActionListener(e -> guardarEspectaculo());
        btnEliminar.addActionListener(e -> eliminarEspectaculo());
        tabla.getSelectionModel().addListSelectionListener(e -> {if (!e.getValueIsAdjusting()) {cargarDesdeTabla();}});

        cargarEstadiosEnCombo();
        cargarTabla();
    }

    private void cargarEstadiosEnCombo() 
    {
        try
        {
            cmbEstadio.removeAllItems();
            List<Estadio> estadios = daoEstadio.consultarTodos();
            for (Estadio e : estadios) 
            {
                cmbEstadio.addItem(e);
            }
        } catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar estadios: " + e.getMessage());
        }
    }

    private void cargarTabla() 
    {
        try 
        {
            List<Espectaculo> lista = daoEspectaculo.consultarTodos();
            modeloTabla.setRowCount(0);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            for (Espectaculo esp : lista) 
            {
                String nombreEstadio = esp.getEstadio() != null ? esp.getEstadio().getNombre() : "";
                String fechaStr = esp.getFechaHora() != null ? sdf.format(esp.getFechaHora()) : "";
                modeloTabla.addRow(new Object[]{
                        esp.getId(),
                        nombreEstadio,
                        esp.getTitulo(),
                        fechaStr,
                        esp.getPrecio()
                });
            }

        } 
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this, "Error al cargar espectáculos: " + e.getMessage());
        }
    }

    private void guardarEspectaculo() 
    {
        try 
        {
            Estadio estadio = (Estadio) cmbEstadio.getSelectedItem();
            String titulo = txtTitulo.getText().trim();
            String fechaTexto = txtFechaHora.getText().trim();
            String precioTexto = txtPrecioBase.getText().trim();

            if (estadio == null || titulo.isEmpty() || fechaTexto.isEmpty() || precioTexto.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this, "Todos los campos son olbigatorios.");
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Timestamp fechaHora;
            try 
            {
                fechaHora = new Timestamp(sdf.parse(fechaTexto).getTime());
            } 
            catch (ParseException pe) 
            {
                JOptionPane.showMessageDialog(this, "Fecha/hora inválida. Usá formato: yyyy-MM-dd HH:mm");
                return;
            }

            float precio = Float.parseFloat(precioTexto);

            Espectaculo esp = new Espectaculo();
            esp.setTitulo(titulo);
            esp.setFechaHora(fechaHora);
            esp.setEstadio(estadio);
            esp.setPrecio(precio);

            if (espectaculoSeleccionadoId == null) 
            {
                daoEspectaculo.insertar(esp);
                JOptionPane.showMessageDialog(this, "Espectáculo guardado correctamente.");
            } 
            else 
            {
                esp.setId(espectaculoSeleccionadoId);
                daoEspectaculo.modificar(esp);
                JOptionPane.showMessageDialog(this, "Espectáculo modificado correctamente.");
            }

            limpiarFormulario();
            cargarTabla();

        } 
        catch (DaoException e)
        {
            JOptionPane.showMessageDialog(this, "Error al guardar espectáculo: " + e.getMessage());
        }
    }

    private void limpiarFormulario() 
    {
        espectaculoSeleccionadoId = null;
        txtTitulo.setText("");
        txtFechaHora.setText("");
        txtPrecioBase.setText("");
        tabla.clearSelection();
        btnGuardar.setText("Guardar");
    }

    private void cargarDesdeTabla() 
    {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            return;
        }

        espectaculoSeleccionadoId = (Integer) tabla.getValueAt(fila, 0);
        String nombreEstadio = (String) tabla.getValueAt(fila, 1);
        String titulo = (String) tabla.getValueAt(fila, 2);
        String fechaHora = (String) tabla.getValueAt(fila, 3);
        String precio = String.valueOf(tabla.getValueAt(fila, 4));

        txtTitulo.setText(titulo);
        txtFechaHora.setText(fechaHora);
        txtPrecioBase.setText(precio);

        //FIJARSE EL BREAK!!!
        for (int i = 0; i < cmbEstadio.getItemCount(); i++) {
            Estadio est = cmbEstadio.getItemAt(i);
            if (est != null && est.getNombre().equals(nombreEstadio)) 
            {
                cmbEstadio.setSelectedIndex(i);
                break;
            }
        }

        btnGuardar.setText("Modificar");
    }

    private void eliminarEspectaculo() 
    {
        
        int fila = tabla.getSelectedRow();
        if (fila == -1) 
        {
            JOptionPane.showMessageDialog(this, "Seleccioná un espectáculo para eliminar.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,"¿Querés eliminar este espectáculo?","Confirmar",JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) 
        {
            try 
            {
                int id = (Integer) tabla.getValueAt(fila, 0);
                daoEspectaculo.eliminar(id);
                JOptionPane.showMessageDialog(this, "Espectáculo eliminado correctamente.");
                limpiarFormulario();
                cargarTabla();
            } 
            catch (DaoException e) 
            {
                JOptionPane.showMessageDialog(this, "Error al eliminar espectáculo: " + e.getMessage());
            }
        }
    }
}
