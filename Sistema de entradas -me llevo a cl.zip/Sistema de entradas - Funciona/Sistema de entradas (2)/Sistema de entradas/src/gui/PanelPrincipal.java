package gui;

import javax.swing.*;

import entidades.Usuario;

import java.awt.*;

public class PanelPrincipal extends JFrame {

    private PanelManager panelManager;
    Usuario usuarioLogueado;
        

    public PanelPrincipal(Usuario usuarioLogueado) {

    
        this.usuarioLogueado = usuarioLogueado;
        setTitle("CocoTeck - Usuario: " + usuarioLogueado.getNombre() +" (" + usuarioLogueado.getRol().getNombre() + ")");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        
        setTitle("CocoTeck");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        JPanel barra = new JPanel();
        barra.setBackground(new Color(244, 170, 190)); // tu rosa viejo
        barra.setLayout(new FlowLayout(FlowLayout.CENTER, 40, 10));

        JButton btnEstadios      = crearBotonMenu("Estadios");
        JButton btnUbicaciones   = crearBotonMenu("Ubicaciones");
        JButton btnEspectaculos  = crearBotonMenu("Espectáculos");
        JButton btnEntradas      = crearBotonMenu("Entradas");

        barra.add(btnEstadios);
        barra.add(btnUbicaciones);
        barra.add(btnEspectaculos);
        barra.add(btnEntradas);

        add(barra, BorderLayout.NORTH);

        panelManager = new PanelManager();
        add(panelManager, BorderLayout.CENTER);

        //Estadios
        JPopupMenu menuEstadios = new JPopupMenu();
        JMenuItem itemEstVer   = new JMenuItem("Ver estadios");
        JMenuItem itemEstAdmin = new JMenuItem("Administración");
        menuEstadios.add(itemEstVer);
        menuEstadios.add(itemEstAdmin);
        btnEstadios.addActionListener(e ->menuEstadios.show(btnEstadios, 0, btnEstadios.getHeight()));
        itemEstVer.addActionListener(e ->panelManager.mostrarPanel("EstadiosVer"));
        itemEstAdmin.addActionListener(e ->panelManager.mostrarPanel("EstadiosAdmin"));

        //Ubicaciones
        JPopupMenu menuUbic = new JPopupMenu();
        JMenuItem itemUbicVer   = new JMenuItem("Ver ubicaciones");
        JMenuItem itemUbicAdmin = new JMenuItem("Administración");
        menuUbic.add(itemUbicVer);
        menuUbic.add(itemUbicAdmin);
        btnUbicaciones.addActionListener(e ->menuUbic.show(btnUbicaciones, 0, btnUbicaciones.getHeight()));
        itemUbicVer.addActionListener(e ->panelManager.mostrarPanel("UbicacionesVer"));
        itemUbicAdmin.addActionListener(e ->panelManager.mostrarPanel("UbicacionesAdmin"));

        //Especrtaculos
        JPopupMenu menuEsp = new JPopupMenu();
        JMenuItem itemEspVer   = new JMenuItem("Ver espectáculos");
        JMenuItem itemEspAdmin = new JMenuItem("Administración");
        menuEsp.add(itemEspVer);
        menuEsp.add(itemEspAdmin);
        btnEspectaculos.addActionListener(e ->menuEsp.show(btnEspectaculos, 0, btnEspectaculos.getHeight()));
        itemEspVer.addActionListener(e ->panelManager.mostrarPanel("EspectaculosVer"));
        itemEspAdmin.addActionListener(e ->panelManager.mostrarPanel("EspectaculosAdmin"));

        btnEntradas.addActionListener(e ->JOptionPane.showMessageDialog(this,"La sección Entradas todavía no está implementada."));
    }

    private JButton crearBotonMenu(String texto) 
    {
        JButton btn = new JButton(texto);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setForeground(Color.DARK_GRAY);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
