package gui;

import dao.DaoException;
import dao.DaoUbicacionEntrada;
import entidades.UbicacionEntrada;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelListadoUbicaciones extends JPanel {

    private JTable tablaUbicaciones;
    private DefaultTableModel modeloTabla;
    private DaoUbicacionEntrada daoUbicacion;

    public PanelListadoUbicaciones() {

        daoUbicacion = new DaoUbicacionEntrada();

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Listado de ubicaciones");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        add(lblTitulo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Estadio", "Nombre", "Capacidad", "Precio"}, 0) 
        {
            @Override
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };

        tablaUbicaciones = new JTable(modeloTabla);
        tablaUbicaciones.setRowHeight(22);
        tablaUbicaciones.getTableHeader().setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(tablaUbicaciones);
        add(scroll, BorderLayout.CENTER);

        cargarTabla();
    }

    private void cargarTabla() 
    {
        modeloTabla.setRowCount(0);
        try 
        {
            List<UbicacionEntrada> lista = daoUbicacion.consultarTodos();
            for (UbicacionEntrada u : lista) {
                String nombreEstadio = (u.getEstadio() != null) ? u.getEstadio().getNombre() : "";
                modeloTabla.addRow(new Object[]{
                        u.getId(),
                        nombreEstadio,
                        u.getnombre(),
                        u.getCapacidad(),
                        u.getPrecio()
                });
            }
        } catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al cargar ubicaciones: " + e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
