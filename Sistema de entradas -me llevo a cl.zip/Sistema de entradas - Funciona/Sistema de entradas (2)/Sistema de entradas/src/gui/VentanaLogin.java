package gui;

import dao.DaoException;
import dao.DaoUsuario;
import entidades.Usuario;

import javax.swing.*;
import java.awt.*;

public class VentanaLogin extends JFrame {

    private JTextField txtMail;
    private JPasswordField txtClave;
    private JButton btnIngresar;

    private DaoUsuario daoUsuario;

    public VentanaLogin() {

        daoUsuario = new DaoUsuario();

        setTitle("Login - CocoTeck");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        Color rosaSuave = new Color(244, 205, 210);
        Color azulTitulo = new Color(5, 51, 66);

    
        JLabel lblTitulo = new JLabel("Iniciar sesión");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(azulTitulo);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(lblTitulo, BorderLayout.NORTH);

    
        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.setBackground(Color.WHITE);
        panelCentro.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Mail
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Mail:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtMail = new JTextField();
        panelCentro.add(txtMail, gbc);

        // Clave
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        panelCentro.add(new JLabel("Clave:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        txtClave = new JPasswordField();
        panelCentro.add(txtClave, gbc);

        add(panelCentro, BorderLayout.CENTER);

        // Botón ingresar
        JPanel panelBoton = new JPanel();
        panelBoton.setBackground(rosaSuave);
        panelBoton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btnIngresar = new JButton("Ingresar");
        btnIngresar.setBackground(azulTitulo);
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setFocusPainted(false);

        panelBoton.add(btnIngresar);
        add(panelBoton, BorderLayout.SOUTH);


        btnIngresar.addActionListener(e -> intentarLogin());
        txtClave.addActionListener(e -> intentarLogin());
    }

    private void intentarLogin() 
    {
        String mail = txtMail.getText().trim();
        String clave = new String(txtClave.getPassword());
        if (mail.isEmpty() || clave.isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Completá mail y clave.");
            return;
        }

        try 
        {
            Usuario usuario = daoUsuario.buscarPorMailYClave(mail, clave);

            if (usuario == null) 
            {
                JOptionPane.showMessageDialog(this, "Usuario o clave incorrectos.");
                return;
            }

            PanelPrincipal ventanaPrincipal = new PanelPrincipal(usuario);
            ventanaPrincipal.setVisible(true);
            dispose();

        }
        catch (DaoException ex) 
        {
            JOptionPane.showMessageDialog(this, "Error en la base de datos: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaLogin login = new VentanaLogin();
            login.setVisible(true);
        });
    }
}

