package gui;

import dao.DaoEstadio;
import dao.DaoException;
import entidades.Estadio;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelListadoEstadios extends JPanel {

    private JTable tablaEstadios;
    private DefaultTableModel modeloTabla;
    private DaoEstadio daoEstadio;

    public PanelListadoEstadios() {

        daoEstadio = new DaoEstadio();

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel lblTitulo = new JLabel("Listado de estadios");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));

        add(lblTitulo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Dirección", "Capacidad"}, 0) 
        {
            @Override
            public boolean isCellEditable(int row, int column) 
            {
                return false;
            }
        };

        tablaEstadios = new JTable(modeloTabla);
        tablaEstadios.setRowHeight(22);
        tablaEstadios.getTableHeader().setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(tablaEstadios);
        add(scroll, BorderLayout.CENTER);

        cargarTabla();
    }

    private void cargarTabla() 
    {
        modeloTabla.setRowCount(0);
        try 
        {
            List<Estadio> lista = daoEstadio.consultarTodos();
            for (Estadio e : lista) 
            {
                modeloTabla.addRow(new Object[]{
                        e.getId(),
                        e.getNombre(),
                        e.getDireccion(),
                        e.getCapacidad()
                });
            }
        }
        catch (DaoException e) 
        {
            JOptionPane.showMessageDialog(this,"Error al cargar estadios: " + e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
