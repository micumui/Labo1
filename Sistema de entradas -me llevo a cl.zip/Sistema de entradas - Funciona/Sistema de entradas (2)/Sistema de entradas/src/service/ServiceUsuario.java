package service;


import dao.DaoException;
import dao.DaoUsuario;
import entidades.Usuario;

public class ServiceUsuario {
    
    private DaoUsuario daoUsuario;

    public ServiceUsuario()
    {
        daoUsuario = new DaoUsuario();
    }

    public void insertar(Usuario usuario) throws ServiceException
    {
        try{
            daoUsuario.insertar(usuario);
        }
        catch(DaoException e)
        {
            throw new ServiceException("Error en la base de datos. ");
        }

    }
    
}
