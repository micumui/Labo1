package service;

import dao.DaoEspectaculo;
import dao.DaoException;
import entidades.Espectaculo;


public class ServiceEspectaculo {
    private DaoEspectaculo daoEspectaculo;

    public ServiceEspectaculo()
    {
        daoEspectaculo = new DaoEspectaculo();
    }

    public void insertar(Espectaculo espectaculo) throws ServiceException
    {
        try
        {
            daoEspectaculo.insertar(espectaculo);
        }
        catch(DaoException e)
        {
            throw new ServiceException("Error en la base de datos. ");
        }

    }
    
}